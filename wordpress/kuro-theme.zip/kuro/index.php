<?php
/**
 * KURO — generated from index.html by wordpress/build_theme.py. Do not edit by hand.
 */
if (!defined('ABSPATH')) { exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>KURO — Design &amp; Engineering Studio</title>
<meta name="description" content="KURO builds high-converting websites, custom AI WhatsApp &amp; lead automation and sharp motion visuals for gyms, gaming cafes and ambitious brands. Mumbai · remote worldwide.">
<meta name="theme-color" content="#09090b">
<meta property="og:type" content="website">
<meta property="og:title" content="KURO — Design &amp; Engineering Studio">
<meta property="og:description" content="High-converting websites, AI automation and motion visuals built to grow your business. Mumbai · remote worldwide.">
<meta property="og:url" content="https://kuro-agency-website.vercel.app/">
<meta name="twitter:card" content="summary">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%2309090b'/%3E%3Cpath d='M19 15h7v14l12-14h9L34 30l14 19h-9L29 35l-3 3v11h-7z' fill='%23fafafa'/%3E%3Ccircle cx='50' cy='48' r='4' fill='%236366f1'/%3E%3C/svg%3E">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Geist:wght@300..800&family=Geist+Mono:wght@400;500&family=Instrument+Serif:ital@1&display=swap" rel="stylesheet">
<script>document.documentElement.classList.add('js');</script>
<style>
/* =========================================================
   TOKENS
   ========================================================= */
:root{
  --bg:#09090b;
  --surface:#121214;
  --surface-2:#18181b;
  --surface-3:#1f1f23;
  --line:rgba(255,255,255,.08);
  --line-2:rgba(255,255,255,.12);
  --line-3:rgba(255,255,255,.22);
  --text:#fafafa;
  --text-2:#a1a1aa;
  --text-3:#8b8b94;
  --indigo:#6366f1;
  --indigo-hi:#818cf8;
  --indigo-soft:#a5b4fc;
  --violet:#8b5cf6;
  --violet-hi:#a78bfa;

  --ease:cubic-bezier(.16,1,.3,1);
  --ease-io:cubic-bezier(.65,0,.35,1);
  --dur:.4s;

  --r-sm:10px; --r:16px; --r-lg:24px; --r-xl:32px;
  --gutter:clamp(16px,4vw,48px);
  --max:1440px;
  --header-h:72px;

  --font-sans:'Geist',ui-sans-serif,system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;
  --font-serif:'Instrument Serif',ui-serif,Georgia,'Times New Roman',serif;
  --font-mono:'Geist Mono',ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;

  --fs-display:clamp(2.5rem,1.05rem + 7.2vw,8.25rem);
  --fs-h2:clamp(2.125rem,1.15rem + 3.7vw,4.75rem);
  --fs-h3:clamp(1.375rem,1.1rem + 1vw,1.875rem);
  --fs-lead:clamp(1.0625rem,.98rem + .4vw,1.3125rem);
}

/* =========================================================
   BASE
   ========================================================= */
*,*::before,*::after{box-sizing:border-box}
html,body,h1,h2,h3,h4,p,ul,ol,dl,dd,figure,fieldset,legend{margin:0;padding:0}
ul,ol{list-style:none}
fieldset{border:0;min-width:0}
img,svg{display:block;max-width:100%}
button,input,textarea{font:inherit;color:inherit;letter-spacing:inherit}
button{background:none;border:0;cursor:pointer;padding:0}
a{color:inherit;text-decoration:none}
html{-webkit-text-size-adjust:100%;text-size-adjust:100%;color-scheme:dark;background:var(--bg);scroll-padding-top:calc(var(--header-h) + 12px)}
@media (prefers-reduced-motion:no-preference){html{scroll-behavior:smooth}}
body{min-height:100vh;background:var(--bg);color:var(--text);font-family:var(--font-sans);font-size:1rem;line-height:1.6;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;overflow-x:clip}
body::after{content:'';position:fixed;inset:0;pointer-events:none;z-index:200;opacity:.035;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='180' height='180'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='180' height='180' filter='url(%23n)'/%3E%3C/svg%3E")}
::selection{background:rgba(99,102,241,.55);color:#fff}
:focus-visible{outline:2px solid var(--indigo-soft);outline-offset:3px;border-radius:6px}
.sr-only{position:absolute!important;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
.skip{position:fixed;left:16px;top:12px;z-index:300;background:var(--text);color:var(--bg);padding:10px 16px;border-radius:999px;font-weight:600;font-size:14px;transform:translateY(-160%);transition:transform var(--dur) var(--ease)}
.skip:focus{transform:none}
.wrap{width:min(100% - var(--gutter)*2, var(--max));margin-inline:auto}
.mono{font-family:var(--font-mono)}

/* Type */
.eyebrow{display:inline-flex;align-items:center;gap:10px;font-family:var(--font-mono);font-size:12px;line-height:1.4;letter-spacing:.08em;text-transform:uppercase;color:var(--text-3)}
.eyebrow .idx{color:var(--indigo-soft)}
.eyebrow .rule{width:28px;height:1px;background:var(--line-3)}
.h-em{font-family:var(--font-serif);font-style:italic;font-weight:400;letter-spacing:-.01em;font-size:1.07em;line-height:0;padding-right:.08em;
  background:linear-gradient(100deg,#e0e7ff 0%,#a5b4fc 42%,#c4b5fd 100%);-webkit-background-clip:text;background-clip:text;color:transparent}
.section{position:relative;padding-block:clamp(96px,12vw,176px)}
.section + .section{border-top:1px solid var(--line)}
.section-head{display:grid;gap:22px;align-items:end}
.section-title{font-size:var(--fs-h2);line-height:1.02;letter-spacing:-.045em;font-weight:600;text-wrap:balance;max-width:17ch}
.section-lead{color:var(--text-2);font-size:var(--fs-lead);line-height:1.55;max-width:46ch;text-wrap:pretty}
@media (min-width:960px){
  .section-head{grid-template-columns:minmax(0,1.35fr) minmax(0,1fr);column-gap:64px}
  .section-head .eyebrow{grid-column:1/-1}
  .section-head .section-lead{justify-self:end;padding-bottom:.5em}
}

/* Buttons */
.btn{position:relative;display:inline-flex;align-items:center;justify-content:center;gap:10px;height:48px;padding:0 22px;border-radius:999px;font-size:15px;font-weight:500;line-height:1;white-space:nowrap;isolation:isolate;
  transition:transform var(--dur) var(--ease),border-color var(--dur) var(--ease),background-color var(--dur) var(--ease),color var(--dur) var(--ease)}
.btn svg{width:16px;height:16px;flex:none;transition:transform var(--dur) var(--ease)}
.btn:hover svg.arr{transform:translateX(3px)}
.btn:active{transform:scale(.97)}
.btn-primary{background:var(--text);color:var(--bg)}
.btn-primary::before{content:'';position:absolute;inset:-1px;border-radius:inherit;z-index:-1;opacity:0;
  box-shadow:0 0 0 4px rgba(99,102,241,.28),0 12px 40px -8px rgba(99,102,241,.75);transition:opacity var(--dur) var(--ease)}
.btn-primary:hover::before,.btn-primary:focus-visible::before{opacity:1}
.btn-ghost{border:1px solid var(--line-2);color:var(--text);background:rgba(255,255,255,.02)}
.btn-ghost:hover{border-color:var(--line-3);background:rgba(255,255,255,.05)}
.btn-sm{height:40px;padding:0 16px;font-size:14px}
.btn-lg{height:56px;padding:0 28px;font-size:16px}
.btn[disabled]{opacity:.4;pointer-events:none}

/* Underline links */
.u-link{position:relative;display:inline-flex;align-items:center;gap:8px}
.u-link::after{content:'';position:absolute;left:0;right:0;bottom:-3px;height:1px;background:currentColor;transform:scaleX(0);transform-origin:right;transition:transform var(--dur) var(--ease)}
.u-link:hover::after,.u-link:focus-visible::after{transform:scaleX(1);transform-origin:left}

/* Pulse dot */
.pulse{position:relative;width:8px;height:8px;border-radius:50%;background:var(--indigo-hi);flex:none}
.pulse::after{content:'';position:absolute;inset:0;border-radius:50%;background:var(--indigo-hi);animation:pulse 2.4s var(--ease) infinite}
@keyframes pulse{0%{transform:scale(1);opacity:.7}80%,100%{transform:scale(3);opacity:0}}

/* Reveal */
.js [data-reveal]{opacity:0;transform:translate3d(0,28px,0);transition:opacity .9s var(--ease),transform 1s var(--ease);transition-delay:var(--d,0ms)}
.js [data-reveal].is-in{opacity:1;transform:none}

/* =========================================================
   HEADER
   ========================================================= */
.site-header{position:fixed;inset:0 0 auto;z-index:50;height:var(--header-h);transition:transform .55s var(--ease)}
.site-header::before{content:'';position:absolute;inset:0;background:rgba(9,9,11,.7);-webkit-backdrop-filter:blur(12px) saturate(150%);backdrop-filter:blur(12px) saturate(150%);border-bottom:1px solid rgba(255,255,255,.1)}
.site-header.is-condensed{transform:translate3d(0,-10px,0)}
.site-header.is-hidden{transform:translate3d(0,-100%,0)}
.nav-shell{position:relative;height:100%;display:flex;align-items:center;justify-content:space-between;gap:24px;transition:transform .55s var(--ease)}
.site-header.is-condensed .nav-shell{transform:translate3d(0,5px,0)}

.brand{display:inline-flex;align-items:center;gap:12px}
.brand-word{display:inline-flex;align-items:center;gap:3px;font-weight:700;font-size:20px;letter-spacing:.16em}
.brand-word i{width:6px;height:6px;border-radius:50%;background:var(--indigo-hi);margin-left:1px;transition:transform var(--dur) var(--ease),box-shadow var(--dur) var(--ease)}
.brand:hover .brand-word i{transform:scale(1.5);box-shadow:0 0 14px 2px rgba(129,140,248,.7)}
.brand-tag{position:relative;display:inline-block;height:22px;overflow:hidden;padding:0 8px;border:1px solid var(--line-2);border-radius:6px;font-family:var(--font-mono);font-size:10.5px;letter-spacing:.08em;line-height:20px;color:var(--text-3);text-transform:uppercase}
.brand-tag span{display:block;transition:transform var(--dur) var(--ease)}
.brand:hover .brand-tag span{transform:translateY(-100%)}

.nav-links{display:none;gap:32px;font-size:14.5px;color:var(--text-2)}
.nav-links a{position:relative;padding:6px 0;transition:color var(--dur) var(--ease)}
.nav-links a::after{content:'';position:absolute;left:0;right:0;bottom:0;height:1px;background:var(--text);transform:scaleX(0);transform-origin:right;transition:transform var(--dur) var(--ease)}
.nav-links a:hover,.nav-links a.is-active{color:var(--text)}
.nav-links a:hover::after,.nav-links a.is-active::after{transform:scaleX(1);transform-origin:left}
.nav-actions{display:flex;align-items:center;gap:12px}
.nav-status{display:none;align-items:center;gap:10px;font-family:var(--font-mono);font-size:11.5px;letter-spacing:.06em;text-transform:uppercase;color:var(--text-3)}
.nav-cta{display:none}

.menu-toggle{position:relative;width:44px;height:44px;border-radius:50%;border:1px solid var(--line-2);display:grid;place-items:center;transition:border-color var(--dur) var(--ease)}
.menu-toggle:hover{border-color:var(--line-3)}
.menu-toggle span{position:absolute;left:50%;top:50%;width:16px;height:1.5px;margin-left:-8px;background:var(--text);border-radius:2px;transition:transform .5s var(--ease)}
.menu-toggle span:nth-child(1){transform:translateY(-3.5px)}
.menu-toggle span:nth-child(2){transform:translateY(3.5px)}
.menu-toggle[aria-expanded="true"] span:nth-child(1){transform:rotate(45deg)}
.menu-toggle[aria-expanded="true"] span:nth-child(2){transform:rotate(-45deg)}

@media (min-width:560px){.nav-cta{display:inline-flex}}
@media (min-width:920px){
  .nav-links{display:flex}
  .menu-toggle{display:none}
}
@media (min-width:1200px){.nav-status{display:inline-flex}}

/* Mobile menu */
.mobile-menu{position:fixed;inset:0;z-index:45;display:flex;flex-direction:column;
  padding:calc(var(--header-h) + 28px) var(--gutter) calc(28px + env(safe-area-inset-bottom));
  background:radial-gradient(90% 60% at 100% 0%,rgba(99,102,241,.16),transparent 60%),var(--bg);
  transform:translate3d(100%,0,0);visibility:hidden;
  transition:transform .75s var(--ease),visibility 0s linear .75s;overflow-y:auto}
.mobile-menu.is-open{transform:none;visibility:visible;transition:transform .75s var(--ease),visibility 0s}
.mm-item{opacity:0;transform:translate3d(0,28px,0);transition:opacity .5s var(--ease),transform .6s var(--ease)}
.mobile-menu.is-open .mm-item{opacity:1;transform:none;transition:opacity .7s var(--ease),transform .9s var(--ease);transition-delay:calc(140ms + var(--i) * 70ms)}
.mm-links{display:grid}
.mm-links a{display:flex;align-items:baseline;gap:18px;padding:14px 0;border-bottom:1px solid var(--line);font-size:clamp(2.25rem,10vw,3.5rem);font-weight:600;letter-spacing:-.045em;line-height:1.05}
.mm-links a .n{font-family:var(--font-mono);font-size:12px;letter-spacing:.08em;color:var(--indigo-soft);font-weight:400}
.mm-foot{margin-top:auto;padding-top:36px;display:grid;gap:22px}
.mm-foot .btn{width:100%}
.mm-meta{display:flex;flex-wrap:wrap;justify-content:space-between;gap:12px;font-size:14px;color:var(--text-2)}
.mm-social{display:flex;gap:18px}
@media (min-width:920px){.mobile-menu{display:none}}

/* =========================================================
   HERO
   ========================================================= */
.hero{position:relative;min-height:100vh;min-height:100svh;display:flex;flex-direction:column;justify-content:flex-end;padding-top:calc(var(--header-h) + clamp(56px,10vh,120px));overflow:hidden;isolation:isolate}
.hero-bg{position:absolute;inset:0;z-index:-1;pointer-events:none}
.hero-aurora{position:absolute;inset:-20% -10% auto;height:90%;
  background:radial-gradient(42% 46% at 72% 30%,rgba(99,102,241,.30),transparent 70%),radial-gradient(36% 40% at 30% 18%,rgba(139,92,246,.20),transparent 70%),radial-gradient(30% 30% at 55% 60%,rgba(56,189,248,.06),transparent 70%);
  animation:drift 22s var(--ease-io) infinite alternate}
@keyframes drift{from{transform:translate3d(-3%,0,0) scale(1)}to{transform:translate3d(3%,4%,0) scale(1.08)}}
.hero-grid,.hero-lens-grid{background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='72' height='72'%3E%3Cpath d='M72 .5H.5V72' fill='none' stroke='%23fff' stroke-opacity='.07'/%3E%3C/svg%3E");background-position:0 0}
.hero-grid{position:absolute;inset:0;-webkit-mask-image:radial-gradient(ellipse 75% 70% at 50% 35%,#000 20%,transparent 78%);mask-image:radial-gradient(ellipse 75% 70% at 50% 35%,#000 20%,transparent 78%)}
.hero-lens{position:absolute;left:0;top:0;width:440px;height:440px;margin:-220px 0 0 -220px;border-radius:50%;overflow:hidden;opacity:0;transition:opacity .8s var(--ease);will-change:transform;
  -webkit-mask-image:radial-gradient(circle,#000 0%,rgba(0,0,0,.6) 35%,transparent 70%);mask-image:radial-gradient(circle,#000 0%,rgba(0,0,0,.6) 35%,transparent 70%)}
.hero-lens-grid{position:absolute;left:0;top:0;width:100vw;height:100vh;will-change:transform;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='72' height='72'%3E%3Cpath d='M72 .5H.5V72' fill='none' stroke='%23a5b4fc' stroke-opacity='.55'/%3E%3Ccircle cx='.5' cy='.5' r='1.5' fill='%23c7d2fe'/%3E%3C/svg%3E")}
.hero-glow{position:absolute;left:0;top:0;width:760px;height:760px;margin:-380px 0 0 -380px;border-radius:50%;opacity:0;transition:opacity 1s var(--ease);will-change:transform;
  background:radial-gradient(circle,rgba(99,102,241,.22) 0%,rgba(139,92,246,.08) 35%,transparent 65%)}
.hero.is-pointer .hero-lens,.hero.is-pointer .hero-glow{opacity:1}
.hero-fade{position:absolute;inset:auto 0 0;height:40%;background:linear-gradient(to bottom,transparent,var(--bg))}

.hero-inner{position:relative;padding-bottom:clamp(48px,8vh,96px)}
.hero-badge{display:inline-flex;align-items:center;gap:12px;padding:7px 14px 7px 12px;border:1px solid var(--line-2);border-radius:999px;background:rgba(18,18,20,.6);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);font-size:13.5px;color:var(--text-2)}
.hero-badge b{color:var(--text);font-weight:500}
@media (max-width:479px){.hero-badge .badge-more{display:none}}
.hero-title{margin-top:28px;font-size:min(var(--fs-display),9vw);font-weight:600;line-height:.96;letter-spacing:-.055em}
.hero-title .ln{display:block;overflow:hidden;padding:0 .12em .1em 0;margin-bottom:-.1em}
.hero-title .ln-i{display:inline-block}
.hero-foot{display:grid;gap:32px;margin-top:clamp(28px,4vw,48px)}
.hero-lead{max-width:52ch;color:var(--text-2);font-size:var(--fs-lead);line-height:1.55;text-wrap:pretty}
.hero-lead strong{color:var(--text);font-weight:500}
.hero-ctas{display:flex;flex-wrap:wrap;gap:12px}
@media (min-width:960px){.hero-foot{grid-template-columns:1fr auto;align-items:end;gap:48px}}
.hero-meta{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px 24px;margin-top:clamp(40px,6vw,72px);padding-top:22px;border-top:1px solid var(--line)}
.hero-meta div{display:grid;gap:4px}
.hero-meta dt{font-family:var(--font-mono);font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--text-3)}
.hero-meta dd{font-size:14.5px;color:var(--text)}
.hero-meta .scroll-cue{display:none}
@media (min-width:768px){
  .hero-meta{grid-template-columns:repeat(4,minmax(0,1fr))}
  .hero-meta .scroll-cue{display:flex;justify-content:flex-end;align-items:center;gap:12px}
}
.scroll-cue{font-family:var(--font-mono);font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--text-3)}
.scroll-cue .track{position:relative;width:1px;height:36px;background:var(--line-2);overflow:hidden}
.scroll-cue .track::after{content:'';position:absolute;left:0;top:0;width:1px;height:100%;background:var(--indigo-soft);transform:translateY(-100%);animation:cue 2.2s var(--ease-io) infinite}
@keyframes cue{0%{transform:translateY(-100%)}60%,100%{transform:translateY(100%)}}

/* Hero entrance */
.js .hero-title .ln-i{transform:translate3d(0,108%,0)}
.js [data-hero]{opacity:0;transform:translate3d(0,18px,0)}
.is-ready .hero-title .ln-i{transform:none;transition:transform 1.2s var(--ease) calc(120ms + var(--i) * 90ms)}
.is-ready [data-hero]{opacity:1;transform:none;transition:opacity 1s var(--ease) var(--d,0ms),transform 1.1s var(--ease) var(--d,0ms)}

/* Marquee */
.marquee{position:relative;border-top:1px solid var(--line);border-bottom:1px solid var(--line);overflow:hidden;padding:18px 0;
  -webkit-mask-image:linear-gradient(90deg,transparent,#000 10%,#000 90%,transparent);mask-image:linear-gradient(90deg,transparent,#000 10%,#000 90%,transparent)}
.marquee-track{display:flex;width:max-content;animation:marquee 46s linear infinite}
.marquee:hover .marquee-track{animation-play-state:paused}
.marquee-group{display:flex;align-items:center;flex:none}
.marquee-group span{font-family:var(--font-mono);font-size:13px;letter-spacing:.1em;text-transform:uppercase;color:var(--text-2);white-space:nowrap;padding:0 28px}
.marquee-group i{width:5px;height:5px;transform:rotate(45deg);background:var(--indigo-hi);flex:none}
@keyframes marquee{to{transform:translate3d(-50%,0,0)}}

/* =========================================================
   SERVICES — BENTO
   ========================================================= */
.bento{display:grid;grid-template-columns:minmax(0,1fr);gap:20px;margin-top:clamp(48px,6vw,80px)}
@media (min-width:768px){
  .bento{grid-template-columns:repeat(3,minmax(0,1fr))}
  .b-web{grid-column:1/3}
  .b-ai{grid-column:3}
  .b-brand{grid-column:1/-1}
}
@media (min-width:960px){
  .b-brand .card-body{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.35fr);grid-template-rows:auto 1fr;column-gap:clamp(28px,4vw,56px);align-items:start}
  .b-brand .card-top{grid-column:1;grid-row:1}
  .b-brand .bullets{grid-column:1;grid-row:2;align-self:end}
  .b-brand .v-motion{grid-column:2;grid-row:1/3}
}
.card{position:relative;border-radius:var(--r-lg);border:1px solid var(--line);isolation:isolate;
  background:linear-gradient(180deg,rgba(255,255,255,.035),rgba(255,255,255,0) 38%),var(--surface);
  transition:transform var(--dur) var(--ease),border-color var(--dur) var(--ease)}
.card::after{content:'';position:absolute;inset:0;border-radius:inherit;background:rgba(24,24,27,.8);opacity:0;z-index:-1;transition:opacity var(--dur) var(--ease)}
.card:hover{transform:translate3d(0,-3px,0);border-color:var(--line-2)}
.card:hover::after{opacity:1}
.card-ring{position:absolute;inset:-1px;border-radius:inherit;padding:1px;overflow:hidden;pointer-events:none;opacity:0;transition:opacity var(--dur) var(--ease);
  -webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;
  mask:linear-gradient(#000 0 0) content-box exclude,linear-gradient(#000 0 0)}
.card-ring i{position:absolute;left:0;top:0;width:340px;height:340px;margin:-170px 0 0 -170px;border-radius:50%;
  background:radial-gradient(circle,rgba(224,231,255,.95) 0%,rgba(129,140,248,.75) 22%,rgba(139,92,246,.25) 45%,transparent 68%)}
.card-spot{position:absolute;inset:0;border-radius:inherit;overflow:hidden;pointer-events:none;z-index:-1;opacity:0;transition:opacity var(--dur) var(--ease)}
.card-spot i{position:absolute;left:0;top:0;width:560px;height:560px;margin:-280px 0 0 -280px;border-radius:50%;background:radial-gradient(circle,rgba(99,102,241,.13),transparent 62%)}
.card:hover .card-ring,.card:hover .card-spot,.card:focus-within .card-ring{opacity:1}
.card-body{position:relative;height:100%;display:flex;flex-direction:column;gap:20px;padding:clamp(22px,2.4vw,32px)}
.card-top{display:flex;justify-content:space-between;align-items:flex-start;gap:16px}
.card-idx{font-family:var(--font-mono);font-size:12px;letter-spacing:.08em;color:var(--text-3)}
.card-icon{width:40px;height:40px;border-radius:12px;border:1px solid var(--line-2);display:grid;place-items:center;color:var(--indigo-soft);background:rgba(99,102,241,.06)}
.card-icon svg{width:19px;height:19px}
.card-title{font-size:var(--fs-h3);font-weight:600;letter-spacing:-.03em;line-height:1.15;text-wrap:balance}
.card-title .card-idx{display:block;margin-bottom:8px}
.card-text{color:var(--text-2);font-size:15.5px;line-height:1.6;max-width:52ch;text-wrap:pretty}
.card-copy{display:grid;gap:10px}
.chips{display:flex;flex-wrap:wrap;gap:8px}
.chips li{display:inline-flex;align-items:center;gap:7px;padding:6px 11px;border:1px solid var(--line-2);border-radius:999px;font-size:12.5px;color:var(--text-2);background:rgba(255,255,255,.015)}
.chips li::before{content:'';width:4px;height:4px;border-radius:50%;background:var(--indigo-hi)}
.card-visual{position:relative;border-radius:var(--r);border:1px solid var(--line);background:var(--bg);overflow:hidden;min-height:190px}

/* Bullets */
.bullets{display:grid;gap:12px}
.bullets li{display:grid;grid-template-columns:20px minmax(0,1fr);gap:12px;align-items:start;font-size:15px;line-height:1.5;color:var(--text-2)}
.bullets li::before{content:'';width:20px;height:20px;margin-top:1px;border-radius:50%;border:1px solid rgba(165,180,252,.35);
  background:rgba(99,102,241,.14) url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12'%3E%3Cpath d='M2.5 6.2l2.3 2.3 4.7-5' fill='none' stroke='%23c7d2fe' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E") center/11px no-repeat}

/* Browser frame (bento + work) */
.browser{position:relative;border-radius:var(--r);border:1px solid var(--line-2);background:#0e0e11;overflow:hidden;isolation:isolate;transform:translateZ(0)}
.browser-bar{display:flex;align-items:center;gap:6px;height:34px;padding:0 12px;border-bottom:1px solid var(--line);background:#141417}
.browser-bar i{width:9px;height:9px;border-radius:50%;background:var(--surface-3);flex:none}
.browser-url{margin:0 auto;display:inline-flex;align-items:center;gap:6px;min-width:0;max-width:64%;padding:4px 12px;border-radius:999px;background:var(--bg);border:1px solid var(--line);font-family:var(--font-mono);font-size:11px;color:var(--text-2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.browser-url svg{width:10px;height:10px;flex:none;color:#6ee7b7}
.browser-view{position:relative;aspect-ratio:16/10;overflow:hidden;background:var(--surface)}
.browser-view img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:top center;transition:transform 1.2s var(--ease)}
.card:hover .browser-view img,.proj:hover .browser-view img{transform:scale(1.04)}

/* Status pills */
.pill{display:inline-flex;align-items:center;gap:8px;padding:6px 12px;border-radius:999px;border:1px solid var(--line-2);background:rgba(9,9,11,.66);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);font-family:var(--font-mono);font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--text-2);white-space:nowrap}
.pill.star{color:var(--indigo-soft);border-color:rgba(165,180,252,.42);background:rgba(99,102,241,.12)}
.status-live{display:inline-flex;align-items:center;gap:8px;padding:6px 12px;border-radius:999px;background:rgba(6,40,30,.72);border:1px solid rgba(52,211,153,.42);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);color:#6ee7b7;font-family:var(--font-mono);font-size:11px;letter-spacing:.08em;text-transform:uppercase;white-space:nowrap;box-shadow:0 0 26px -6px rgba(52,211,153,.55)}
.status-live i{position:relative;width:7px;height:7px;border-radius:50%;background:#34d399;flex:none}
.status-live i::after{content:'';position:absolute;inset:0;border-radius:50%;background:#34d399;animation:pulse 2.2s var(--ease) infinite}

/* 01 visual: browser preview */
.v-web .browser-view{aspect-ratio:16/8.4}
.v-web .status-live{position:absolute;right:12px;top:12px;z-index:2}
.perf{position:absolute;left:12px;bottom:12px;z-index:2;display:flex;align-items:center;gap:10px;padding:6px 14px 6px 6px;border-radius:999px;background:rgba(9,9,11,.8);border:1px solid var(--line-2);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px)}
.perf svg{width:36px;height:36px;flex:none}
@media (max-width:600px){.perf{transform:scale(.78);transform-origin:left bottom}.v-web .status-live{transform:scale(.82);transform-origin:right top}}
.perf span{display:grid;line-height:1.2}
.perf b{font-size:14px;font-weight:600}
.perf small{font-family:var(--font-mono);font-size:10.5px;letter-spacing:.06em;text-transform:uppercase;color:var(--text-3)}

/* 02 visual: pipeline */
.v-flow{flex:1;display:flex;flex-direction:column;justify-content:center;padding:20px 16px;border-radius:var(--r);border:1px solid var(--line);background:radial-gradient(90% 60% at 50% 0%,rgba(99,102,241,.16),transparent 70%),var(--bg)}
.flow-node{display:grid;grid-template-columns:40px minmax(0,1fr);gap:12px;align-items:center;padding:12px;border-radius:14px;border:1px solid var(--line-2);background:var(--surface)}
.flow-node .ic{width:40px;height:40px;border-radius:11px;display:grid;place-items:center;border:1px solid var(--line-2);color:var(--indigo-soft);background:rgba(99,102,241,.08)}
.flow-node .ic svg{width:18px;height:18px}
.flow-node b{display:block;font-size:14px;font-weight:600;line-height:1.3}
.flow-node small{display:block;margin-top:2px;font-family:var(--font-mono);font-size:10.5px;letter-spacing:.04em;color:var(--text-3)}
.flow-node.hl{border-color:rgba(165,180,252,.5);background:linear-gradient(135deg,rgba(99,102,241,.2),rgba(139,92,246,.06)),var(--surface)}
.flow-node.ok .ic{color:#6ee7b7;border-color:rgba(52,211,153,.4);background:rgba(16,185,129,.1)}
.flow-link{position:relative;width:2px;height:30px;margin-left:31px;background:var(--line-3);overflow:hidden}
.flow-link::after{content:'';position:absolute;left:0;top:0;width:2px;height:12px;border-radius:2px;background:var(--indigo-soft);box-shadow:0 0 8px var(--indigo-hi);animation:flow 1.8s var(--ease-io) infinite}
.flow-link.l2::after{animation-delay:.9s}
@keyframes flow{from{transform:translate3d(0,-14px,0)}to{transform:translate3d(0,32px,0)}}

/* 03 visual: kinetic type + tokens */
.v-motion{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(0,1fr);border-radius:var(--r);border:1px solid var(--line);overflow:hidden;min-height:220px}
@media (max-width:600px){.v-motion{grid-template-columns:minmax(0,1fr)}}
.km-stage{position:relative;display:flex;flex-direction:column;justify-content:center;padding:24px 24px 40px;background:#fafafa;color:#09090b;overflow:hidden}
.km-line{display:block;overflow:hidden;font-weight:700;font-size:clamp(2rem,1.2rem + 2.4vw,3.25rem);letter-spacing:-.055em;line-height:1}
.km-line span{display:inline-block;animation:kin 5s var(--ease) infinite}
.km-line:nth-child(2) span{animation-delay:.14s}
.km-line em{font-family:var(--font-serif);font-style:italic;font-weight:400;letter-spacing:-.01em;color:#4f46e5}
@keyframes kin{0%,6%{transform:translate3d(0,110%,0)}16%,84%{transform:none}94%,100%{transform:translate3d(0,-110%,0)}}
.km-time{position:absolute;left:24px;right:24px;bottom:18px;height:3px;border-radius:3px;background:rgba(9,9,11,.12);overflow:hidden}
.km-time i{position:absolute;inset:0;background:#09090b;transform-origin:left;animation:playhead 5s linear infinite}
@keyframes playhead{from{transform:scaleX(0)}to{transform:scaleX(1)}}
.km-tokens{display:grid;align-content:center;gap:12px;padding:20px;background:var(--bg);font-family:var(--font-mono);font-size:11.5px;color:var(--text-3)}
.km-tokens .swatches{display:flex;gap:8px}
.km-tokens .swatches span{width:26px;height:26px;border-radius:50%;border:1px solid var(--line-2)}
.km-tokens div.tk{display:flex;justify-content:space-between;gap:12px;padding-bottom:7px;border-bottom:1px dashed var(--line-2)}
.km-tokens b{font-weight:400;color:var(--text-2)}

/* =========================================================
   WORK — websites we've shipped
   ========================================================= */
.proj{position:relative;display:grid;gap:22px;align-content:start}
.proj-media{display:block;border-radius:var(--r);position:relative}
.proj-media .browser{box-shadow:0 30px 70px -40px rgba(0,0,0,.9)}
.proj-overlay{position:absolute;left:14px;bottom:14px;z-index:3;display:flex;flex-wrap:wrap;gap:8px;pointer-events:none}
.proj-overlay .pill{background:rgba(9,9,11,.82);color:var(--text)}
.proj-overlay .pill.star{background:rgba(30,27,75,.9);color:var(--indigo-soft)}
.proj-body{display:grid;gap:18px;align-content:start;min-width:0}
.proj-badges{display:flex;flex-wrap:wrap;gap:8px}
.proj-ctas{display:flex;flex-wrap:wrap;align-items:center;gap:14px 24px;padding-top:4px}
.proj-feature{margin-top:clamp(48px,6vw,80px);padding:clamp(14px,2vw,22px);border-radius:var(--r-xl);border:1px solid rgba(165,180,252,.28);
  background:radial-gradient(70% 100% at 0% 0%,rgba(99,102,241,.16),transparent 60%),radial-gradient(50% 80% at 100% 100%,rgba(139,92,246,.10),transparent 60%),var(--surface);
  box-shadow:0 0 0 1px rgba(99,102,241,.06),0 40px 100px -50px rgba(99,102,241,.55)}
.proj-feature .proj-body{padding:6px 8px 10px}
@media (min-width:960px){.proj-feature{grid-template-columns:minmax(0,1.45fr) minmax(0,1fr);gap:40px;align-items:center}.proj-feature .proj-body{padding:10px 18px 10px 0}}
.work-grid{display:grid;grid-template-columns:minmax(0,1fr);gap:56px 20px;margin-top:56px}
@media (min-width:768px){.work-grid{grid-template-columns:repeat(2,minmax(0,1fr));margin-top:clamp(56px,6vw,80px)}}
.case-title{display:flex;align-items:baseline;justify-content:space-between;gap:16px;font-size:clamp(1.75rem,1.2rem + 1.8vw,2.75rem);font-weight:600;letter-spacing:-.04em;line-height:1.05}
.case-title .yr{font-family:var(--font-mono);font-size:12px;font-weight:400;letter-spacing:.08em;color:var(--text-3)}
.case-desc{color:var(--text-2);max-width:56ch;text-wrap:pretty}
.case-meta{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;padding-top:16px;border-top:1px solid var(--line)}
.case-meta dt{font-family:var(--font-mono);font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--text-3);margin-bottom:6px}
.case-meta dd{font-size:14px;color:var(--text);line-height:1.45}
@media (max-width:520px){.case-meta{grid-template-columns:minmax(0,1fr);gap:10px}.case-meta div{display:flex;justify-content:space-between;gap:16px}.case-meta dt{margin:0}.case-meta dd{text-align:right}}
.case-cta{display:inline-flex;align-items:center;gap:8px;font-size:14.5px;color:var(--text);justify-self:start}
.case-cta svg{width:15px;height:15px;transition:transform var(--dur) var(--ease)}
.case-cta:hover svg{transform:translate(2px,-2px)}

/* Templates sub-head */
.tpl-head{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:space-between;gap:10px 32px;margin-top:clamp(64px,8vw,104px);padding-top:28px;border-top:1px solid var(--line)}
.tpl-head h3{font-size:clamp(1.5rem,1.1rem + 1.5vw,2.25rem);font-weight:600;letter-spacing:-.035em;line-height:1.1}
.tpl-head p{color:var(--text-2);max-width:48ch}
.tpl-head + .work-grid{margin-top:32px}

/* =========================================================
   AI AUTOMATION
   ========================================================= */
.auto-grid{display:grid;grid-template-columns:minmax(0,1fr);gap:20px;margin-top:clamp(48px,6vw,80px)}
@media (min-width:900px){.auto-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
.auto-card .card-body{gap:18px}
.metric{align-self:flex-start;display:inline-flex;align-items:center;gap:8px;padding:6px 12px;border-radius:999px;border:1px solid rgba(165,180,252,.42);background:rgba(99,102,241,.12);font-family:var(--font-mono);font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--indigo-soft)}
.metric::before{content:'';width:6px;height:6px;border-radius:50%;background:var(--indigo-hi);box-shadow:0 0 10px var(--indigo-hi)}
.auto-visual{display:flex;flex-direction:column;justify-content:center;gap:10px;min-height:236px;padding:16px;border-radius:var(--r);border:1px solid var(--line);background:radial-gradient(90% 70% at 50% 0%,rgba(99,102,241,.12),transparent 70%),var(--bg)}
.js .auto-card:not(.is-in) .anim{opacity:0;transform:translate3d(0,10px,0)}
.auto-card .anim{transition:opacity .6s var(--ease),transform .7s var(--ease);transition-delay:calc(350ms + var(--a,0) * 260ms)}
/* chat */
.chat-head{display:flex;align-items:center;gap:10px;padding-bottom:10px;border-bottom:1px solid var(--line);font-size:13px;font-weight:600}
.chat-head .av{width:30px;height:30px;border-radius:50%;display:grid;place-items:center;background:linear-gradient(135deg,#10b981,#0f766e);color:#ecfdf5;flex:none}
.chat-head .av svg{width:15px;height:15px}
.chat-head small{display:block;font-family:var(--font-mono);font-size:10.5px;font-weight:400;color:#6ee7b7}
.bub{max-width:88%;padding:9px 12px;border-radius:14px;font-size:13px;line-height:1.45}
.bub.in{align-self:flex-start;background:var(--surface-2);border:1px solid var(--line);border-top-left-radius:4px}
.bub.out{align-self:flex-end;background:linear-gradient(135deg,rgba(16,185,129,.24),rgba(16,185,129,.1));border:1px solid rgba(52,211,153,.32);border-top-right-radius:4px}
.bub time{display:block;margin-top:4px;font-family:var(--font-mono);font-size:10px;color:var(--text-3);text-align:right}
.bub.out time{color:#6ee7b7}
.quick{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:6px}
.quick span{padding:5px 10px;border-radius:999px;border:1px solid rgba(52,211,153,.35);font-size:11.5px;color:#a7f3d0}
/* booking */
.book{display:grid;gap:4px;padding:14px;border-radius:14px;border:1px solid rgba(52,211,153,.35);background:linear-gradient(135deg,rgba(16,185,129,.14),transparent 70%),var(--surface)}
.book.alt{border-color:rgba(165,180,252,.35);background:linear-gradient(135deg,rgba(99,102,241,.16),transparent 70%),var(--surface)}
.book-h{display:flex;align-items:center;gap:10px;font-size:14px;font-weight:600}
.book-h .ck{width:22px;height:22px;border-radius:50%;display:grid;place-items:center;background:#10b981;color:#052e22;flex:none}
.book.alt .book-h .ck{background:var(--indigo-hi);color:var(--bg)}
.book-h .ck svg{width:11px;height:11px}
.book small{font-family:var(--font-mono);font-size:11px;color:var(--text-3);padding-left:32px}
.sync{display:grid;gap:7px;margin-top:4px;font-size:12.5px;color:var(--text-2)}
.sync li{display:flex;align-items:center;gap:8px}
.sync li svg{width:12px;height:12px;color:#34d399;flex:none}
/* pipeline board */
.stages{display:flex;flex-wrap:wrap;align-items:center;gap:4px 6px;font-family:var(--font-mono);font-size:10px;letter-spacing:.06em;text-transform:uppercase;color:var(--text-3)}
.stages i{width:10px;height:1px;background:var(--line-3)}
.lead{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:10px;padding:10px 12px;border-radius:12px;background:var(--surface);border:1px solid var(--line);font-size:13px}
.lead small{display:block;font-family:var(--font-mono);font-size:10.5px;color:var(--text-3)}
.st{padding:4px 9px;border-radius:999px;font-family:var(--font-mono);font-size:10px;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap;border:1px solid var(--line-2);color:var(--text-2)}
.st-follow{border-color:rgba(251,191,36,.4);color:#fcd34d;background:rgba(251,191,36,.08)}
.st-booked{border-color:rgba(165,180,252,.45);color:var(--indigo-soft);background:rgba(99,102,241,.12)}
.st-paid{border-color:rgba(52,211,153,.45);color:#6ee7b7;background:rgba(16,185,129,.12)}
.auto-cta{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:16px 24px;margin-top:20px;padding:20px 24px;border-radius:var(--r-lg);border:1px solid var(--line);background:var(--surface)}
.auto-cta p{color:var(--text-2);max-width:60ch}
.auto-cta p b{color:var(--text);font-weight:500}

/* =========================================================
   BRIEF BUILDER
   ========================================================= */
.brief{display:grid;gap:20px;margin-top:clamp(48px,6vw,80px)}
@media (min-width:1024px){.brief{grid-template-columns:minmax(0,1.65fr) minmax(0,1fr);align-items:start}}
.brief-main{border-radius:var(--r-xl);border:1px solid var(--line);background:var(--surface);padding:clamp(22px,3.2vw,44px);min-width:0}
.brief-steps{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;font-size:13px;color:var(--text-3)}
.brief-steps li{display:flex;align-items:center;gap:8px;min-width:0;transition:color var(--dur) var(--ease)}
.brief-steps .n{flex:none;width:24px;height:24px;border-radius:50%;display:grid;place-items:center;border:1px solid var(--line-2);font-family:var(--font-mono);font-size:11px;transition:background-color var(--dur) var(--ease),border-color var(--dur) var(--ease),color var(--dur) var(--ease)}
.brief-steps .t{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.brief-steps li.is-current{color:var(--text)}
.brief-steps li.is-current .n{border-color:var(--indigo-hi);color:var(--text);background:rgba(99,102,241,.18)}
.brief-steps li.is-done .n{background:var(--text);border-color:var(--text);color:var(--bg)}
@media (max-width:520px){.brief-steps .t{display:none}.brief-steps li.is-current .t{display:block}.brief-steps{grid-template-columns:auto auto auto 1fr}}
.brief-bar{margin-top:18px;height:2px;border-radius:2px;background:var(--line);overflow:hidden}
.brief-bar span{display:block;height:100%;background:linear-gradient(90deg,var(--indigo),var(--violet-hi));transform-origin:left;transform:scaleX(.25);transition:transform .7s var(--ease)}
.brief-form{margin-top:clamp(28px,3.5vw,44px)}
.js .brief-step{display:none}
.brief-step.is-active{display:block;animation:stepIn .7s var(--ease) both}
.brief-form[data-dir="back"] .brief-step.is-active{animation-name:stepBack}
@keyframes stepIn{from{opacity:0;transform:translate3d(24px,0,0)}}
@keyframes stepBack{from{opacity:0;transform:translate3d(-24px,0,0)}}
.brief-q{float:left;width:100%;font-size:clamp(1.5rem,1.15rem + 1.3vw,2.25rem);font-weight:600;letter-spacing:-.035em;line-height:1.15;outline:none}
.brief-hint{clear:both;padding-top:8px;color:var(--text-2);font-size:15px}
.opt-grid{display:grid;grid-template-columns:minmax(0,1fr);gap:12px;margin-top:26px}
@media (min-width:600px){.opt-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (min-width:1280px){.opt-grid.three{grid-template-columns:repeat(3,minmax(0,1fr))}}
.opt{position:relative;display:block;cursor:pointer}
.opt input{position:absolute;opacity:0;width:1px;height:1px;pointer-events:none}
.opt-card{position:relative;display:grid;grid-template-columns:auto 1fr;gap:4px 14px;align-items:start;height:100%;padding:16px 46px 16px 16px;border-radius:var(--r);border:1px solid var(--line-2);background:var(--bg);
  transition:border-color var(--dur) var(--ease),transform var(--dur) var(--ease)}
.opt-card::before{content:'';position:absolute;inset:0;border-radius:inherit;background:linear-gradient(135deg,rgba(99,102,241,.16),rgba(139,92,246,.06));opacity:0;transition:opacity var(--dur) var(--ease)}
.opt:hover .opt-card{border-color:var(--line-3)}
.opt:active .opt-card{transform:scale(.985)}
.opt input:checked + .opt-card{border-color:rgba(165,180,252,.7)}
.opt input:checked + .opt-card::before{opacity:1}
.opt input:focus-visible + .opt-card{outline:2px solid var(--indigo-soft);outline-offset:3px}
.opt-icon{position:relative;grid-row:span 2;width:38px;height:38px;border-radius:11px;display:grid;place-items:center;border:1px solid var(--line-2);color:var(--indigo-soft);background:rgba(255,255,255,.02)}
.opt-icon svg{width:18px;height:18px}
.opt-title{position:relative;font-weight:600;font-size:16px;letter-spacing:-.01em;line-height:1.3}
.opt-desc{position:relative;font-size:13.5px;color:var(--text-2);line-height:1.45}
.opt-card.plain{grid-template-columns:1fr}
.opt-card.plain .opt-title{font-size:18px}
.opt-check{position:absolute;right:14px;top:14px;width:20px;height:20px;border-radius:50%;border:1px solid var(--line-3);display:grid;place-items:center;transition:background-color var(--dur) var(--ease),border-color var(--dur) var(--ease)}
.opt-check svg{width:11px;height:11px;color:var(--bg);opacity:0;transform:scale(.5);transition:opacity var(--dur) var(--ease),transform var(--dur) var(--ease)}
.opt input[type="radio"] + .opt-card .opt-check{border-radius:50%}
.opt input:checked + .opt-card .opt-check{background:var(--text);border-color:var(--text)}
.opt input:checked + .opt-card .opt-check svg{opacity:1;transform:none}
.field-error{margin-top:14px;display:flex;align-items:center;gap:8px;color:#fca5a5;font-size:14px}
.field-error[hidden]{display:none}
.fields{display:grid;grid-template-columns:minmax(0,1fr);gap:16px;margin-top:26px}
@media (min-width:600px){.fields{grid-template-columns:repeat(2,minmax(0,1fr))}.fields .full{grid-column:1/-1}}
.field{display:grid;gap:8px}
.field label{font-size:13.5px;color:var(--text-2)}
.field label .opt-l{color:var(--text-3)}
.field input,.field textarea{width:100%;padding:14px 16px;border-radius:12px;border:1px solid var(--line-2);background:var(--bg);color:var(--text);font-size:16px;outline:none;transition:border-color var(--dur) var(--ease),box-shadow var(--dur) var(--ease)}
.field textarea{resize:vertical;min-height:120px;line-height:1.5}
.field input::placeholder,.field textarea::placeholder{color:#76767f}
.field input:hover,.field textarea:hover{border-color:var(--line-3)}
.field input:focus,.field textarea:focus{border-color:var(--indigo-hi);box-shadow:0 0 0 4px rgba(99,102,241,.18)}
.field input[aria-invalid="true"]{border-color:#f87171}
.field .field-error{margin-top:0}
.brief-nav{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:clamp(28px,3.5vw,40px);padding-top:22px;border-top:1px solid var(--line)}
.brief-count{font-family:var(--font-mono);font-size:12px;letter-spacing:.06em;color:var(--text-3)}
.brief-nav .btn-ghost[hidden]{display:inline-flex;visibility:hidden}
.brief-done{text-align:left;display:grid;gap:18px;justify-items:start;padding:clamp(8px,2vw,24px) 0;outline:none}
.brief-done[hidden]{display:none}
.done-icon{width:56px;height:56px;border-radius:50%;display:grid;place-items:center;background:linear-gradient(135deg,var(--indigo),var(--violet));animation:pop .8s var(--ease) both}
.done-icon svg{width:24px;height:24px}
@keyframes pop{from{transform:scale(.4);opacity:0}}
.brief-done h3{font-size:clamp(1.75rem,1.3rem + 1.6vw,2.5rem);font-weight:600;letter-spacing:-.04em;line-height:1.1}
.brief-done p{color:var(--text-2);max-width:54ch}
.brief-done p a{color:var(--text);border-bottom:1px solid var(--line-3)}
.done-actions{display:flex;flex-wrap:wrap;gap:12px}

.brief-summary{border-radius:var(--r-xl);border:1px solid var(--line);background:linear-gradient(180deg,rgba(99,102,241,.08),transparent 45%),var(--surface);padding:clamp(22px,2.6vw,32px);display:grid;gap:22px}
@media (min-width:1024px){.brief-summary{position:sticky;top:calc(var(--header-h) + 20px)}}
.sum-list{display:grid}
.sum-list div{display:grid;grid-template-columns:88px 1fr;gap:12px;padding:13px 0;border-bottom:1px solid var(--line)}
.sum-list dt{font-family:var(--font-mono);font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--text-3);padding-top:3px}
.sum-list dd{font-size:14.5px;color:var(--text)}
.sum-list dd.is-empty{color:var(--text-3)}
.flash{animation:flash .7s var(--ease)}
@keyframes flash{from{opacity:.2;transform:translate3d(0,4px,0)}}
.scope{display:grid;gap:14px;padding:18px;border-radius:var(--r);border:1px solid var(--line);background:var(--bg)}
.scope-head{display:flex;justify-content:space-between;align-items:baseline;gap:12px;font-size:13.5px;color:var(--text-2)}
.scope-head b{font-size:16px;font-weight:600;color:var(--text)}
.scope-meter{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}
.scope-meter i{position:relative;height:6px;border-radius:6px;background:var(--surface-3);overflow:hidden}
.scope-meter i::after{content:'';position:absolute;inset:0;background:linear-gradient(90deg,var(--indigo),var(--violet-hi));transform:scaleX(0);transform-origin:left;transition:transform .6s var(--ease)}
.scope-meter i.on::after{transform:scaleX(1)}
.scope-meter i:nth-child(2)::after{transition-delay:60ms}.scope-meter i:nth-child(3)::after{transition-delay:120ms}.scope-meter i:nth-child(4)::after{transition-delay:180ms}
.scope-facts{display:grid;gap:9px;font-size:14px}
.scope-facts li{display:flex;justify-content:space-between;gap:12px;color:var(--text-2)}
.scope-facts b{color:var(--text);font-weight:500;text-align:right}
.scope-note{display:flex;gap:10px;align-items:flex-start;padding:12px 14px;border-radius:12px;background:rgba(251,191,36,.07);border:1px solid rgba(251,191,36,.22);color:#fde68a;font-size:13.5px;line-height:1.5}
.scope-note[hidden]{display:none}
.sum-foot{font-size:13px;color:var(--text-3);line-height:1.55}

/* =========================================================
   FAQ
   ========================================================= */
.faq-grid{display:grid;gap:48px}
@media (min-width:960px){.faq-grid{grid-template-columns:minmax(0,1fr) minmax(0,1.5fr);gap:80px}.faq-aside{position:sticky;top:calc(var(--header-h) + 32px);align-self:start}}
.faq-aside{display:grid;gap:22px;align-content:start}
.faq-aside p{color:var(--text-2);max-width:40ch}
.faq-list{border-top:1px solid var(--line)}
.faq-item{border-bottom:1px solid var(--line)}
.faq-item h3{font-size:inherit;font-weight:inherit}
.faq-btn{width:100%;display:flex;align-items:center;justify-content:space-between;gap:24px;padding:26px 0;text-align:left;font-size:clamp(1.0625rem,.98rem + .45vw,1.375rem);font-weight:500;letter-spacing:-.02em;line-height:1.35;color:var(--text);transition:color var(--dur) var(--ease)}
.faq-btn:hover{color:var(--indigo-soft)}
.faq-btn:focus-visible{outline-offset:6px}
.pm{position:relative;flex:none;width:36px;height:36px;border-radius:50%;border:1px solid var(--line-2);transition:transform .5s var(--ease),border-color var(--dur) var(--ease),background-color var(--dur) var(--ease)}
.pm::before,.pm::after{content:'';position:absolute;left:50%;top:50%;width:12px;height:1.5px;margin:-.75px 0 0 -6px;border-radius:2px;background:var(--text);transition:transform .5s var(--ease)}
.pm::after{transform:rotate(90deg)}
.faq-item.is-open .pm{transform:rotate(180deg);border-color:rgba(165,180,252,.6);background:rgba(99,102,241,.14)}
.faq-item.is-open .pm::after{transform:rotate(0deg)}
.faq-panel{display:grid;grid-template-rows:0fr;visibility:hidden;transition:grid-template-rows .55s var(--ease),visibility 0s linear .55s}
.faq-item.is-open .faq-panel{grid-template-rows:1fr;visibility:visible;transition:grid-template-rows .55s var(--ease),visibility 0s}
.faq-inner{overflow:hidden}
.faq-inner p{padding:0 56px 28px 0;color:var(--text-2);max-width:62ch;opacity:0;transform:translate3d(0,-8px,0);transition:opacity .4s var(--ease),transform .5s var(--ease)}
.faq-item.is-open .faq-inner p{opacity:1;transform:none;transition-delay:.12s}
.no-js .faq-panel{grid-template-rows:1fr;visibility:visible}
.no-js .faq-inner p{opacity:1;transform:none}

/* =========================================================
   MOTION & EDITS (reference reel)
   ========================================================= */
.reel{display:grid;grid-auto-flow:column;grid-auto-columns:minmax(220px,68vw);gap:16px;margin-top:clamp(48px,6vw,80px);
  overflow-x:auto;scroll-snap-type:x mandatory;overscroll-behavior-x:contain;padding-bottom:14px;scrollbar-width:thin;scrollbar-color:var(--surface-3) transparent;
  margin-inline:calc(var(--gutter) * -1);padding-inline:var(--gutter);scroll-padding-inline:var(--gutter)}
@media (min-width:640px){.reel{grid-auto-columns:minmax(220px,38vw)}}
@media (min-width:1100px){.reel{grid-auto-flow:row;grid-template-columns:repeat(5,minmax(0,1fr));overflow:visible;margin-inline:0;padding-inline:0}}
.clip{position:relative;scroll-snap-align:start;display:flex;flex-direction:column;gap:14px}
.clip-media{position:relative;aspect-ratio:9/16;border-radius:var(--r-lg);overflow:hidden;border:1px solid var(--line);background:var(--surface);isolation:isolate;transform:translateZ(0)}
.clip-media video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transition:transform 1.2s var(--ease)}
.clip:hover .clip-media video{transform:scale(1.04)}
.clip-media::after{content:'';position:absolute;inset:0;pointer-events:none;background:linear-gradient(180deg,rgba(9,9,11,.55) 0%,transparent 22%,transparent 62%,rgba(9,9,11,.85) 100%)}
.clip-ref{position:absolute;left:12px;top:12px;z-index:2;display:inline-flex;align-items:center;gap:7px;padding:5px 10px;border-radius:999px;background:rgba(9,9,11,.62);border:1px solid var(--line-2);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);font-family:var(--font-mono);font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--text)}
.clip-ref i{width:6px;height:6px;border-radius:50%;background:#fbbf24}
.clip-toggle{position:absolute;right:10px;top:10px;z-index:2;width:44px;height:44px;border-radius:50%;display:grid;place-items:center;color:var(--text);background:rgba(9,9,11,.5);border:1px solid var(--line-2);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);opacity:.85;transition:opacity var(--dur) var(--ease),transform var(--dur) var(--ease)}
.clip-toggle:hover{opacity:1;transform:scale(1.06)}
.clip-toggle svg{width:14px;height:14px}
.clip-toggle .i-play{display:none}
.clip.is-paused .clip-toggle .i-play{display:block}
.clip.is-paused .clip-toggle .i-pause{display:none}
.clip-cap{position:absolute;left:14px;right:14px;bottom:14px;z-index:2;display:grid;gap:4px}
.clip-cap b{font-size:17px;font-weight:600;letter-spacing:-.02em;line-height:1.2}
.clip-cap span{font-family:var(--font-mono);font-size:10.5px;letter-spacing:.06em;text-transform:uppercase;color:rgba(250,250,250,.72)}
.clip-info{display:grid;gap:8px}
.clip-info p{font-size:14px;color:var(--text-2);line-height:1.5}
.clip-info small{font-family:var(--font-mono);font-size:11px;letter-spacing:.04em;color:var(--text-3)}
.clip-info .case-cta{font-size:14px}

/* =========================================================
   FOOTER
   ========================================================= */
.site-footer{position:relative;overflow:hidden;border-top:1px solid var(--line);isolation:isolate}
.footer-glow{position:absolute;left:50%;top:0;width:min(1200px,140vw);height:640px;transform:translate3d(-50%,-38%,0);z-index:-1;pointer-events:none;
  background:radial-gradient(50% 50% at 50% 50%,rgba(99,102,241,.22),rgba(139,92,246,.08) 45%,transparent 70%)}
.footer-cta{padding-block:clamp(96px,12vw,168px) clamp(64px,8vw,112px);display:grid;gap:36px;justify-items:start}
.footer-cta h2{font-size:clamp(2.5rem,1.2rem + 5.6vw,7rem);font-weight:600;letter-spacing:-.055em;line-height:.98;max-width:14ch;text-wrap:balance}
.footer-cta-row{display:flex;flex-wrap:wrap;align-items:center;gap:14px 24px}
.mail-link{display:inline-flex;align-items:center;gap:12px;font-size:clamp(1.0625rem,.95rem + .6vw,1.5rem);letter-spacing:-.02em}
.copy-btn{display:inline-grid;place-items:center;width:44px;height:44px;border-radius:50%;border:1px solid var(--line-2);color:var(--text-2);transition:border-color var(--dur) var(--ease),color var(--dur) var(--ease)}
.copy-btn:hover{border-color:var(--line-3);color:var(--text)}
.copy-btn svg{width:16px;height:16px}
.copy-tip{font-family:var(--font-mono);font-size:12px;color:var(--indigo-soft);opacity:0;transform:translate3d(-6px,0,0);transition:opacity var(--dur) var(--ease),transform var(--dur) var(--ease)}
.copy-tip.show{opacity:1;transform:none}
.footer-cols{display:grid;grid-template-columns:minmax(0,1fr);gap:40px;padding-block:56px;border-top:1px solid var(--line)}
@media (min-width:640px){.footer-cols{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (min-width:1024px){.footer-cols{grid-template-columns:minmax(0,1.4fr) repeat(3,minmax(0,1fr))}}
.f-col h3{font-family:var(--font-mono);font-size:11.5px;font-weight:400;letter-spacing:.08em;text-transform:uppercase;color:var(--text-3);margin-bottom:18px}
.f-col p,.f-col li{color:var(--text-2);font-size:15px}
.f-col ul{display:grid;gap:10px}
.f-col a{color:var(--text);transition:color var(--dur) var(--ease)}
.f-col a:hover{color:var(--indigo-soft)}
.f-brand{display:grid;gap:16px;align-content:start}
.f-brand p{max-width:34ch}
.office{display:grid;gap:2px}
.office b{color:var(--text);font-weight:500}
.office span{font-size:13.5px;color:var(--text-3)}
.social a{display:inline-flex;align-items:center;gap:10px}
.social svg{width:16px;height:16px;flex:none}
.social .ext{width:12px;height:12px;opacity:.5;transition:transform var(--dur) var(--ease),opacity var(--dur) var(--ease)}
.social a:hover .ext{opacity:1;transform:translate(2px,-2px)}
.f-time{display:inline-flex;align-items:center;gap:10px;margin-top:6px;font-family:var(--font-mono);font-size:12.5px;color:var(--text-2)}
.footer-bottom{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:8px 16px;padding-block:14px;border-top:1px solid var(--line);font-size:13.5px;color:var(--text-3)}
.footer-bottom .links{display:flex;flex-wrap:wrap;gap:20px}
.footer-bottom button,.footer-bottom a{display:inline-flex;align-items:center;min-height:44px;color:var(--text-2);font-size:13.5px;transition:color var(--dur) var(--ease)}
.footer-bottom button:hover,.footer-bottom a:hover{color:var(--text)}
.footer-word{font-weight:700;font-size:clamp(5rem,27vw,30rem);line-height:.72;letter-spacing:-.06em;text-align:center;margin-bottom:-.06em;user-select:none;pointer-events:none;
  background:linear-gradient(180deg,rgba(255,255,255,.10) 0%,rgba(255,255,255,0) 82%);-webkit-background-clip:text;background-clip:text;color:transparent}

/* =========================================================
   SHARE SHEET
   ========================================================= */
.ss-backdrop{position:fixed;inset:0;z-index:150;background:rgba(5,5,7,.72);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);display:flex;align-items:flex-end;justify-content:center;opacity:0;transition:opacity .35s var(--ease)}
.ss-backdrop[hidden]{display:none}
.ss-backdrop.open{opacity:1}
@media (min-width:640px){.ss-backdrop{align-items:center}}
.ss-sheet{width:100%;max-width:420px;background:var(--surface);border:1px solid var(--line-2);border-radius:22px 22px 0 0;padding:22px 20px calc(22px + env(safe-area-inset-bottom));transform:translate3d(0,24px,0);transition:transform .5s var(--ease);box-shadow:0 -20px 80px rgba(0,0,0,.6)}
@media (min-width:640px){.ss-sheet{border-radius:22px}}
.ss-backdrop.open .ss-sheet{transform:none}
.ss-head{display:flex;justify-content:space-between;gap:14px;margin-bottom:16px}
.ss-head h2{font-size:17px;font-weight:600;letter-spacing:-.02em}
.ss-head p{margin-top:4px;font-family:var(--font-mono);font-size:11.5px;color:var(--text-3);word-break:break-all}
.ss-close{width:36px;height:36px;border-radius:50%;border:1px solid var(--line-2);display:grid;place-items:center;color:var(--text-2);flex:none;transition:color var(--dur) var(--ease),border-color var(--dur) var(--ease)}
.ss-close:hover{color:var(--text);border-color:var(--line-3)}
.ss-close svg{width:14px;height:14px}
.ss-qr{display:flex;gap:14px;align-items:center;background:var(--bg);border:1px solid var(--line);border-radius:16px;padding:14px;margin-bottom:12px}
.ss-qr img{width:104px;height:104px;border-radius:10px;background:#fff;padding:6px;flex:none}
.ss-qr .ph{width:104px;height:104px;border-radius:10px;background:var(--surface-2);flex:none}
.ss-qr div{font-size:13px;color:var(--text-2);line-height:1.5}
.ss-qr b{display:block;color:var(--text);font-weight:600;margin-bottom:2px}
.ss-link{display:flex;gap:8px;margin-bottom:12px}
.ss-link input{flex:1;min-width:0;background:var(--bg);border:1px solid var(--line-2);border-radius:12px;padding:11px 12px;font-family:var(--font-mono);font-size:12px;color:var(--text-2);outline:none}
.ss-link input:focus{border-color:var(--indigo-hi)}
.ss-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px}
.ss-dest{display:flex;flex-direction:column;align-items:center;gap:7px;padding:12px 4px;border-radius:14px;border:1px solid var(--line);background:var(--bg);font-size:11.5px;color:var(--text-2);transition:border-color var(--dur) var(--ease),transform var(--dur) var(--ease)}
.ss-dest:hover{border-color:var(--line-3);transform:translate3d(0,-2px,0);color:var(--text)}
.ss-dest svg{width:20px;height:20px}
.ss-dl{width:100%}

/* =========================================================
   REDUCED MOTION
   ========================================================= */
@media (prefers-reduced-motion:reduce){
  *,*::before,*::after{animation-duration:.001ms!important;animation-iteration-count:1!important;transition-duration:.001ms!important;transition-delay:0ms!important}
  .js [data-reveal],.js [data-hero],.js .hero-title .ln-i{opacity:1;transform:none}
  .marquee-track{animation:none}
  .hero-lens,.hero-glow{display:none}
}
</style>
<?php if (function_exists('is_admin_bar_showing') && is_admin_bar_showing()) : ?>
<style>.site-header{top:32px}.mobile-menu{top:32px}@media (max-width:782px){.site-header,.mobile-menu{top:46px}}</style>
<?php endif; ?>
<?php wp_head(); ?>
</head>
<body>
<a class="skip" href="#main">Skip to content</a>

<!-- ===================== HEADER ===================== -->
<header class="site-header" id="siteHeader">
  <div class="wrap nav-shell">
    <a class="brand" href="#top" aria-label="KURO — back to top">
      <span class="brand-word" aria-hidden="true">KURO<i></i></span>
      <span class="brand-tag" aria-hidden="true"><span>黒 / Studio</span><span>Est. 2026</span></span>
    </a>
    <nav class="nav-links" aria-label="Primary">
      <a href="#services">Services</a>
      <a href="#work">Work</a>
      <a href="#automation">Automation</a>
      <a href="#motion">Motion</a>
      <a href="#contact">Contact</a>
    </nav>
    <div class="nav-actions">
      <span class="nav-status"><span class="pulse" aria-hidden="true"></span>Taking new projects</span>
      <a class="btn btn-primary btn-sm nav-cta" href="#contact">Start a project
        <svg class="arr" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3 8h10m0 0L8.5 3.5M13 8l-4.5 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </a>
      <button class="menu-toggle" id="menuToggle" type="button" aria-expanded="false" aria-controls="mobileMenu" aria-label="Open menu"><span></span><span></span></button>
    </div>
  </div>
</header>

<!-- ===================== MOBILE MENU ===================== -->
<div class="mobile-menu" id="mobileMenu" role="dialog" aria-modal="true" aria-label="Site menu">
  <nav class="mm-links" aria-label="Mobile">
    <a class="mm-item" style="--i:0" href="#services"><span class="n">01</span>Services</a>
    <a class="mm-item" style="--i:1" href="#work"><span class="n">02</span>Work</a>
    <a class="mm-item" style="--i:2" href="#automation"><span class="n">03</span>Automation</a>
    <a class="mm-item" style="--i:3" href="#motion"><span class="n">04</span>Motion</a>
    <a class="mm-item" style="--i:4" href="#contact"><span class="n">05</span>Contact</a>
  </nav>
  <div class="mm-foot">
    <a class="btn btn-primary btn-lg mm-item" style="--i:5" href="#contact">Start a project
      <svg class="arr" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3 8h10m0 0L8.5 3.5M13 8l-4.5 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </a>
    <div class="mm-meta mm-item" style="--i:6">
      <a href="mailto:team.kuroagency@hotmail.com">team.kuroagency@hotmail.com</a>
      <a href="https://wa.me/918700268026" target="_blank" rel="noopener noreferrer">WhatsApp +91 870 026 8026</a>
    </div>
    <div class="mm-social mm-item" style="--i:7">
      <a class="u-link" href="https://x.com/" target="_blank" rel="noopener">X</a>
      <a class="u-link" href="https://www.linkedin.com/" target="_blank" rel="noopener">LinkedIn</a>
      <a class="u-link" href="https://github.com/" target="_blank" rel="noopener">GitHub</a>
      <a class="u-link" href="https://dribbble.com/" target="_blank" rel="noopener">Dribbble</a>
    </div>
  </div>
</div>

<main id="main">

<!-- ===================== HERO ===================== -->
<section class="hero" id="top" aria-labelledby="heroTitle">
  <div class="hero-bg" aria-hidden="true">
    <div class="hero-aurora"></div>
    <div class="hero-grid"></div>
    <div class="hero-glow" id="heroGlow"></div>
    <div class="hero-lens" id="heroLens"><div class="hero-lens-grid" id="heroLensGrid"></div></div>
    <div class="hero-fade"></div>
  </div>

  <div class="wrap hero-inner">
    <p class="hero-badge" data-hero style="--d:0ms"><span class="pulse" aria-hidden="true"></span><span><b>Independent studio</b><span class="badge-more"> — websites, AI automation &amp; motion</span></span></p>

    <h1 class="hero-title" id="heroTitle">
      <span class="ln"><span class="ln-i" style="--i:0">We design and build</span></span>
      <span class="ln"><span class="ln-i" style="--i:1">digital products</span></span>
      <span class="ln"><span class="ln-i" style="--i:2">people <em class="h-em">remember.</em></span></span>
    </h1>

    <div class="hero-foot">
      <p class="hero-lead" data-hero style="--d:420ms"><strong>KURO</strong> partners with ambitious teams to shape brands, design products and engineer them to ship — one senior crew, from the first sketch to launch day and beyond.</p>
      <div class="hero-ctas" data-hero style="--d:520ms">
        <a class="btn btn-primary btn-lg" href="#contact">Start a project
          <svg class="arr" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3 8h10m0 0L8.5 3.5M13 8l-4.5 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </a>
        <a class="btn btn-ghost btn-lg" href="#work">See selected work</a>
      </div>
    </div>

    <dl class="hero-meta" data-hero style="--d:640ms">
      <div><dt>Based in</dt><dd>Mumbai · Remote Worldwide</dd></div>
      <div><dt>What we do</dt><dd>Websites · AI Automation · Motion</dd></div>
      <div><dt>Founded</dt><dd>2026, by three friends</dd></div>
      <div class="scroll-cue" aria-hidden="true"><span>Scroll</span><span class="track"></span></div>
    </dl>
  </div>

  <div class="marquee" aria-hidden="true">
    <div class="marquee-track">
      <div class="marquee-group"><span>Business websites</span><i></i><span>AI WhatsApp bots</span><i></i><span>Lead automation</span><i></i><span>Next.js</span><i></i><span>Vite</span><i></i><span>Slot booking</span><i></i><span>Local SEO</span><i></i><span>Motion edits</span><i></i><span>Brand identity</span><i></i></div>
      <div class="marquee-group"><span>Business websites</span><i></i><span>AI WhatsApp bots</span><i></i><span>Lead automation</span><i></i><span>Next.js</span><i></i><span>Vite</span><i></i><span>Slot booking</span><i></i><span>Local SEO</span><i></i><span>Motion edits</span><i></i><span>Brand identity</span><i></i></div>
    </div>
  </div>
</section>

<!-- ===================== 01 WHAT WE DO ===================== -->
<section class="section" id="services" aria-labelledby="servicesTitle">
  <div class="wrap">
    <header class="section-head">
      <p class="eyebrow" data-reveal><span class="idx">01</span><span class="rule"></span>What we do</p>
      <h2 class="section-title" id="servicesTitle" data-reveal>What we <em class="h-em">do</em>.</h2>
      <p class="section-lead" data-reveal style="--d:100ms">High-converting websites, custom AI automation, and sharp motion visuals built to grow your business.</p>
    </header>

    <div class="bento" data-stagger>
      <!-- 01 / Web -->
      <article class="card b-web" data-spotlight data-reveal>
        <div class="card-ring" aria-hidden="true"><i></i></div>
        <div class="card-spot" aria-hidden="true"><i></i></div>
        <div class="card-body">
          <div class="card-top">
            <h3 class="card-title"><span class="card-idx">01 /</span>Web Engineering &amp; Platforms</h3>
            <span class="card-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="14" rx="2.5"/><path d="M3 8.5h18M8 21h8"/></svg></span>
          </div>
          <div class="v-web" aria-hidden="true">
            <div class="browser">
              <div class="browser-bar"><i></i><i></i><i></i><span class="browser-url"><svg viewBox="0 0 12 12" fill="none" aria-hidden="true"><rect x="2.5" y="5.5" width="7" height="5" rx="1.2" fill="currentColor"/><path d="M4 5.5V4a2 2 0 0 1 4 0v1.5" stroke="currentColor" stroke-width="1.2"/></svg>kouragefitness.in</span></div>
              <div class="browser-view">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/work/kourage-fitness.webp" alt="" width="1600" height="1000" loading="lazy" decoding="async">
                <span class="status-live"><i></i>Live domain</span>
                <span class="perf"><svg viewBox="0 0 36 36"><circle cx="18" cy="18" r="15" fill="none" stroke="rgba(52,211,153,.2)" stroke-width="3"/><circle cx="18" cy="18" r="15" fill="none" stroke="#34d399" stroke-width="3" stroke-linecap="round" stroke-dasharray="93.3 94.3" transform="rotate(-90 18 18)"/><text x="18" y="22" text-anchor="middle" font-size="11" font-weight="700" fill="#6ee7b7" font-family="Geist, sans-serif">99</text></svg><span><b>99</b><small>Performance</small></span></span>
              </div>
            </div>
          </div>
          <ul class="bullets">
            <li>Fast, mobile-first Next.js &amp; Vite websites built to convert visitors into bookings</li>
            <li>Custom web platforms for gyms, gaming cafes, and ambitious brands</li>
            <li>Full custom domain deployment, local SEO, and WhatsApp lead integration</li>
          </ul>
        </div>
      </article>

      <!-- 02 / AI -->
      <article class="card b-ai" data-spotlight data-reveal>
        <div class="card-ring" aria-hidden="true"><i></i></div>
        <div class="card-spot" aria-hidden="true"><i></i></div>
        <div class="card-body">
          <div class="card-top">
            <h3 class="card-title"><span class="card-idx">02 /</span>AI Business Automation</h3>
            <span class="card-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/><rect x="7" y="7" width="10" height="10" rx="2.5"/><path d="M10 12h4"/></svg></span>
          </div>
          <div class="v-flow" aria-hidden="true">
            <div class="flow-node"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/></svg></span><span><b>Website / IG Inquiry</b><small>New lead · 11:42 PM</small></span></div>
            <div class="flow-link"></div>
            <div class="flow-node hl"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M13 3L5 14h6l-1 7 8-11h-6z"/></svg></span><span><b>Instant AI WhatsApp Reply</b><small>Answered in 3 sec · 24/7</small></span></div>
            <div class="flow-link l2"></div>
            <div class="flow-node ok"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><span><b>Booked Client / CRM Sync</b><small>Added to pipeline</small></span></div>
          </div>
          <ul class="bullets">
            <li>24/7 AI lead capture and instant WhatsApp (wa.me) &amp; Instagram DM follow-ups</li>
            <li>Automated slot/session booking and CRM pipeline syncing</li>
            <li>Custom workflow automation that saves 10+ hours of manual admin every week</li>
          </ul>
        </div>
      </article>

      <!-- 03 / Brand & Motion -->
      <article class="card b-brand" data-spotlight data-reveal>
        <div class="card-ring" aria-hidden="true"><i></i></div>
        <div class="card-spot" aria-hidden="true"><i></i></div>
        <div class="card-body">
          <div class="card-top">
            <h3 class="card-title"><span class="card-idx">03 /</span>Brand &amp; Motion Design</h3>
            <span class="card-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="14" height="14" rx="2.5"/><path d="M17 10l4-2.5v9L17 14"/></svg></span>
          </div>
          <div class="v-motion" aria-hidden="true">
            <div class="km-stage">
              <span class="km-line"><span>Make it</span></span>
              <span class="km-line"><span><em>move.</em></span></span>
              <span class="km-time"><i></i></span>
            </div>
            <div class="km-tokens">
              <div class="swatches"><span style="background:#09090b"></span><span style="background:#fafafa"></span><span style="background:#6366f1"></span><span style="background:#8b5cf6"></span></div>
              <div class="tk"><span>--ink</span><b>#09090B</b></div>
              <div class="tk"><span>--accent</span><b>#818CF8</b></div>
              <div class="tk"><span>--display</span><b>Geist 700</b></div>
              <div class="tk"><span>--ease</span><b>.16, 1, .3, 1</b></div>
            </div>
          </div>
          <ul class="bullets">
            <li>High-impact visual identities that make local and digital brands look premium</li>
            <li>Conversion-focused UI/UX designed directly in the browser</li>
            <li>High-retention motion graphics and promotional edits</li>
          </ul>
        </div>
      </article>
    </div>
  </div>
</section>

<!-- ===================== 02 SELECTED WORK ===================== -->
<section class="section" id="work" aria-labelledby="workTitle">
  <div class="wrap">
    <header class="section-head">
      <p class="eyebrow" data-reveal><span class="idx">02</span><span class="rule"></span>Selected work</p>
      <h2 class="section-title" id="workTitle" data-reveal>Websites we've <em class="h-em">shipped</em>.</h2>
      <p class="section-lead" data-reveal style="--d:100ms">Real production builds engineered, deployed, and launched end-to-end.</p>
    </header>

    <!-- Card 01 — flagship -->
    <article class="proj proj-feature" data-reveal>
      <a class="proj-media" href="https://www.kouragefitness.in/" target="_blank" rel="noopener noreferrer" tabindex="-1" aria-hidden="true">
        <div class="browser">
          <div class="browser-bar"><i></i><i></i><i></i><span class="browser-url"><svg viewBox="0 0 12 12" fill="none" aria-hidden="true"><rect x="2.5" y="5.5" width="7" height="5" rx="1.2" fill="currentColor"/><path d="M4 5.5V4a2 2 0 0 1 4 0v1.5" stroke="currentColor" stroke-width="1.2"/></svg>www.kouragefitness.in</span></div>
          <div class="browser-view"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/work/kourage-fitness.webp" alt="" width="1600" height="1000" loading="lazy" decoding="async"></div>
        </div>
      </a>
      <div class="proj-body">
        <div class="proj-badges"><span class="pill star">★ Featured · 01</span><span class="status-live"><i></i>Domain launched — Live</span></div>
        <h3 class="case-title">Kourage Fitness <span class="yr">2026</span></h3>
        <p class="case-desc">Production Next.js web platform launched on a custom .in domain for Kourage Fitness in Mulund West, Mumbai. Built for fast mobile loading, program discovery, and direct WhatsApp member enquiries.</p>
        <dl class="case-meta">
          <div><dt>Client</dt><dd>Kourage Fitness (Mulund West, Mumbai)</dd></div>
          <div><dt>Stack</dt><dd>Next.js · Vercel</dd></div>
          <div><dt>Status</dt><dd>Custom Domain Live</dd></div>
        </dl>
        <div class="proj-ctas">
          <a class="btn btn-primary" href="https://www.kouragefitness.in/" target="_blank" rel="noopener noreferrer">Visit kouragefitness.in <span aria-hidden="true">↗</span><span class="sr-only"> (opens in a new tab)</span></a>
          <a class="case-cta u-link" href="#contact" data-brief="website,automation">Start a similar project →</a>
        </div>
      </div>
    </article>

    <div class="tpl-head" data-reveal>
      <h3>Launch-ready <em class="h-em">templates</em></h3>
      <p>Original landing pages we brand, customise and launch for your business — open the live demos.</p>
    </div>
    <div class="work-grid">
      <article class="proj" data-reveal>
        <a class="proj-media" href="<?php echo esc_url(get_template_directory_uri()); ?>/templates/gaming/" target="_blank" rel="noopener noreferrer" tabindex="-1" aria-hidden="true">
          <div class="browser">
            <div class="browser-bar"><i></i><i></i><i></i><span class="browser-url"><svg viewBox="0 0 12 12" fill="none" aria-hidden="true"><rect x="2.5" y="5.5" width="7" height="5" rx="1.2" fill="currentColor"/><path d="M4 5.5V4a2 2 0 0 1 4 0v1.5" stroke="currentColor" stroke-width="1.2"/></svg>nexus-arena · live demo</span></div>
            <div class="browser-view"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/work/template-gaming.webp" alt="" width="1600" height="1000" loading="lazy" decoding="async"></div>
          </div>
          <span class="proj-overlay"><span class="pill">Template</span><span class="pill star">Gaming cafe + store</span></span>
        </a>
        <div class="proj-body">
          <h3 class="case-title">NEXUS Arena <span class="yr">Landing page</span></h3>
          <p class="case-desc">A landing page for gaming cafes and game stores: a game shop with cart, live station availability, instant slot booking and clear pricing tiers.</p>
          <dl class="case-meta">
            <div><dt>Type</dt><dd>Landing page template</dd></div>
            <div><dt>Features</dt><dd>Game store · Cart · Slot booking</dd></div>
            <div><dt>Best for</dt><dd>Gaming cafes, game shops</dd></div>
          </dl>
          <div class="proj-ctas">
            <a class="btn btn-ghost btn-sm" href="<?php echo esc_url(get_template_directory_uri()); ?>/templates/gaming/" target="_blank" rel="noopener noreferrer">View live demo <span aria-hidden="true">↗</span><span class="sr-only"> (opens in a new tab)</span></a>
            <a class="case-cta u-link" href="#contact" data-brief="venue">Get this for your business →</a>
          </div>
        </div>
      </article>

      <article class="proj" data-reveal>
        <a class="proj-media" href="<?php echo esc_url(get_template_directory_uri()); ?>/templates/restaurant/" target="_blank" rel="noopener noreferrer" tabindex="-1" aria-hidden="true">
          <div class="browser">
            <div class="browser-bar"><i></i><i></i><i></i><span class="browser-url"><svg viewBox="0 0 12 12" fill="none" aria-hidden="true"><rect x="2.5" y="5.5" width="7" height="5" rx="1.2" fill="currentColor"/><path d="M4 5.5V4a2 2 0 0 1 4 0v1.5" stroke="currentColor" stroke-width="1.2"/></svg>ember-and-oak · live demo</span></div>
            <div class="browser-view"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/work/template-restaurant.webp" alt="" width="1600" height="1000" loading="lazy" decoding="async"></div>
          </div>
          <span class="proj-overlay"><span class="pill">Template</span><span class="pill star">Restaurant</span></span>
        </a>
        <div class="proj-body">
          <h3 class="case-title">Ember &amp; Oak <span class="yr">Landing page</span></h3>
          <p class="case-desc">A landing page for restaurants and cafes: a tabbed menu with online ordering, table reservations with guest count and occasion, and opening hours.</p>
          <dl class="case-meta">
            <div><dt>Type</dt><dd>Landing page template</dd></div>
            <div><dt>Features</dt><dd>Menu · Ordering · Reservations</dd></div>
            <div><dt>Best for</dt><dd>Restaurants, cafes, cloud kitchens</dd></div>
          </dl>
          <div class="proj-ctas">
            <a class="btn btn-ghost btn-sm" href="<?php echo esc_url(get_template_directory_uri()); ?>/templates/restaurant/" target="_blank" rel="noopener noreferrer">View live demo <span aria-hidden="true">↗</span><span class="sr-only"> (opens in a new tab)</span></a>
            <a class="case-cta u-link" href="#contact" data-brief="website">Get this for your business →</a>
          </div>
        </div>
      </article>
    </div>
  </div>
</section>

<!-- ===================== 03 AI AUTOMATION ===================== -->
<section class="section" id="automation" aria-labelledby="autoTitle">
  <div class="wrap">
    <header class="section-head">
      <p class="eyebrow" data-reveal><span class="idx">03</span><span class="rule"></span>AI automation</p>
      <h2 class="section-title" id="autoTitle" data-reveal>AI automation that <em class="h-em">boosts</em> your business.</h2>
      <p class="section-lead" data-reveal style="--d:100ms">We plug custom AI workflows into your website, WhatsApp, and Instagram so you never miss a lead or waste hours on manual follow-ups.</p>
    </header>

    <div class="auto-grid" data-stagger>
      <article class="card auto-card" data-spotlight data-reveal>
        <div class="card-ring" aria-hidden="true"><i></i></div>
        <div class="card-spot" aria-hidden="true"><i></i></div>
        <div class="card-body">
          <span class="metric">&lt; 5 sec response time</span>
          <div class="auto-visual" aria-hidden="true">
            <div class="chat-head"><span class="av"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/></svg></span><span>Gym assistant<small>● online · AI replies</small></span></div>
            <div class="bub in anim" style="--a:0">Hi! What are your monthly fees and timings?<time>11:42 PM</time></div>
            <div class="bub out anim" style="--a:1">Hey! Plans start at ₹1,499/month and we're open 6 AM – 11 PM. Want a free trial session tomorrow?<time>11:42 PM · auto-reply in 3s</time></div>
            <div class="quick anim" style="--a:2"><span>Book free trial</span><span>Send location</span></div>
          </div>
          <h3 class="card-title">Instant WhatsApp &amp; IG Lead Capture</h3>
          <p class="card-text">Automatically greet, qualify, and answer pricing/location FAQs on WhatsApp and Instagram DMs 24/7 — turning late-night visitors into paying customers.</p>
        </div>
      </article>

      <article class="card auto-card" data-spotlight data-reveal>
        <div class="card-ring" aria-hidden="true"><i></i></div>
        <div class="card-spot" aria-hidden="true"><i></i></div>
        <div class="card-body">
          <span class="metric">Zero missed bookings</span>
          <div class="auto-visual" aria-hidden="true">
            <div class="book anim" style="--a:0"><span class="book-h"><span class="ck"><svg viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span>Trial Session Confirmed</span><small>Tue, 18 Nov · 7:00 PM · Strength floor</small></div>
            <div class="book alt anim" style="--a:1"><span class="book-h"><span class="ck"><svg viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span>Gaming Slot Confirmed</span><small>PS5 Station 2 · Sat · 8 – 9 PM</small></div>
            <ul class="sync anim" style="--a:2">
              <li><svg viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>Synced to Google Calendar</li>
              <li><svg viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>WhatsApp reminder scheduled · 2 hrs before</li>
            </ul>
          </div>
          <h3 class="card-title">Automated Slot &amp; Appointment Booking</h3>
          <p class="card-text">Let clients book gym trials, gaming cafe slots, or discovery calls automatically with instant WhatsApp reminders that cut no-shows.</p>
        </div>
      </article>

      <article class="card auto-card" data-spotlight data-reveal>
        <div class="card-ring" aria-hidden="true"><i></i></div>
        <div class="card-spot" aria-hidden="true"><i></i></div>
        <div class="card-body">
          <span class="metric">10+ hrs saved / week</span>
          <div class="auto-visual" aria-hidden="true">
            <div class="stages anim" style="--a:0"><span>New lead</span><i></i><span>Follow-up sent</span><i></i><span>Booked</span><i></i><span>Paid</span></div>
            <div class="lead anim" style="--a:1"><span>Website form<small>Membership enquiry</small></span><span class="st">New lead</span></div>
            <div class="lead anim" style="--a:1.5"><span>Instagram DM<small>Pricing question</small></span><span class="st st-follow">Follow-up sent</span></div>
            <div class="lead anim" style="--a:2"><span>WhatsApp<small>PS5 slot · Saturday</small></span><span class="st st-booked">Booked</span></div>
            <div class="lead anim" style="--a:2.5"><span>Free trial<small>Converted to monthly plan</small></span><span class="st st-paid">Paid</span></div>
          </div>
          <h3 class="card-title">CRM Sync &amp; Operations Workflows</h3>
          <p class="card-text">Connect your website forms directly to Google Sheets, Notion, or your CRM with automated follow-up sequences and lead alerts.</p>
        </div>
      </article>
    </div>

    <div class="auto-cta" data-reveal>
      <p><b>Not sure what to automate first?</b> Tell us how leads reach you today and we'll map the quickest win.</p>
      <a class="btn btn-primary" href="#contact" data-brief="automation">Automate my leads <svg class="arr" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3 8h10m0 0L8.5 3.5M13 8l-4.5 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
    </div>
  </div>
</section>

<!-- ===================== MOTION & EDITS ===================== -->
<section class="section" id="motion" aria-labelledby="motionTitle">
  <div class="wrap">
    <header class="section-head">
      <p class="eyebrow" data-reveal><span class="idx">04</span><span class="rule"></span>Motion &amp; edits</p>
      <h2 class="section-title" id="motionTitle" data-reveal>Edits in this <em class="h-em">style</em>, made for you.</h2>
      <p class="section-lead" data-reveal style="--d:100ms">A reference reel of styles we love and can produce — anime edits, cinematic promos, kinetic type and motion reels. These clips are by other creators; your project gets original work, built from scratch.</p>
    </header>

    <div class="reel" data-stagger>
      <article class="clip" data-reveal>
        <div class="clip-media">
          <span class="clip-ref"><i aria-hidden="true"></i>Reference</span>
          <button class="clip-toggle" type="button" aria-label="Pause cinematic food promo video"><svg class="i-play" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M4.5 2.8v10.4L13 8z"/></svg><svg class="i-pause" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><rect x="3.5" y="2.5" width="3" height="11" rx="1"/><rect x="9.5" y="2.5" width="3" height="11" rx="1"/></svg></button>
          <video muted loop playsinline preload="none" poster="<?php echo esc_url(get_template_directory_uri()); ?>/assets/motion/food-3d.jpg" aria-label="Cinematic food promo — reference clip by another creator"><source src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/motion/food-3d.mp4" type="video/mp4"></video>
          <div class="clip-cap"><b>Cinematic food promo</b><span>Restaurant · Reels</span></div>
        </div>
        <div class="clip-info">
          <p>Moody, slow-motion food and kitchen promos that make people hungry.</p>
          <small>Reference film by SevenMagpie</small>
          <a class="case-cta u-link" href="#contact" data-brief="motion">Brief a similar edit <svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M5 11l6-6m0 0H6m5 0v5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
        </div>
      </article>
      <article class="clip" data-reveal>
        <div class="clip-media">
          <span class="clip-ref"><i aria-hidden="true"></i>Reference</span>
          <button class="clip-toggle" type="button" aria-label="Pause anime fight edit video"><svg class="i-play" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M4.5 2.8v10.4L13 8z"/></svg><svg class="i-pause" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><rect x="3.5" y="2.5" width="3" height="11" rx="1"/><rect x="9.5" y="2.5" width="3" height="11" rx="1"/></svg></button>
          <video muted loop playsinline preload="none" poster="<?php echo esc_url(get_template_directory_uri()); ?>/assets/motion/anime-120fps.jpg" aria-label="Anime fight edit — reference clip by another creator"><source src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/motion/anime-120fps.mp4" type="video/mp4"></video>
          <div class="clip-cap"><b>Anime fight edit</b><span>120fps · Sync to beat</span></div>
        </div>
        <div class="clip-info">
          <p>High-frame-rate anime edits with impact frames, flashes and beat-synced cuts.</p>
          <small>Reference edit · anime: Bleach (Tite Kubo / Studio Pierrot)</small>
          <a class="case-cta u-link" href="#contact" data-brief="motion">Brief a similar edit <svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M5 11l6-6m0 0H6m5 0v5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
        </div>
      </article>
      <article class="clip" data-reveal>
        <div class="clip-media">
          <span class="clip-ref"><i aria-hidden="true"></i>Reference</span>
          <button class="clip-toggle" type="button" aria-label="Pause anime live wallpaper video"><svg class="i-play" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M4.5 2.8v10.4L13 8z"/></svg><svg class="i-pause" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><rect x="3.5" y="2.5" width="3" height="11" rx="1"/><rect x="9.5" y="2.5" width="3" height="11" rx="1"/></svg></button>
          <video muted loop playsinline preload="none" poster="<?php echo esc_url(get_template_directory_uri()); ?>/assets/motion/anime-wallpaper.jpg" aria-label="Anime live wallpaper — reference clip by another creator"><source src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/motion/anime-wallpaper.mp4" type="video/mp4"></video>
          <div class="clip-cap"><b>Anime live wallpaper</b><span>Seamless loop · Vertical</span></div>
        </div>
        <div class="clip-info">
          <p>Looping animated wallpapers for phones, streams and socials.</p>
          <small>Reference edit · anime: Jujutsu Kaisen (Gege Akutami / MAPPA)</small>
          <a class="case-cta u-link" href="#contact" data-brief="motion">Brief a similar edit <svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M5 11l6-6m0 0H6m5 0v5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
        </div>
      </article>
      <article class="clip" data-reveal>
        <div class="clip-media">
          <span class="clip-ref"><i aria-hidden="true"></i>Reference</span>
          <button class="clip-toggle" type="button" aria-label="Pause kinetic typography video"><svg class="i-play" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M4.5 2.8v10.4L13 8z"/></svg><svg class="i-pause" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><rect x="3.5" y="2.5" width="3" height="11" rx="1"/><rect x="9.5" y="2.5" width="3" height="11" rx="1"/></svg></button>
          <video muted loop playsinline preload="none" poster="<?php echo esc_url(get_template_directory_uri()); ?>/assets/motion/kinetic-type.jpg" aria-label="Kinetic typography — reference clip by another creator"><source src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/motion/kinetic-type.mp4" type="video/mp4"></video>
          <div class="clip-cap"><b>Kinetic typography</b><span>Explainer · Short-form</span></div>
        </div>
        <div class="clip-info">
          <p>Animated type that turns a script into a punchy explainer.</p>
          <small>Reference reel · original creator via Pinterest</small>
          <a class="case-cta u-link" href="#contact" data-brief="motion">Brief a similar edit <svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M5 11l6-6m0 0H6m5 0v5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
        </div>
      </article>
      <article class="clip" data-reveal>
        <div class="clip-media">
          <span class="clip-ref"><i aria-hidden="true"></i>Reference</span>
          <button class="clip-toggle" type="button" aria-label="Pause motion graphics reel video"><svg class="i-play" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M4.5 2.8v10.4L13 8z"/></svg><svg class="i-pause" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><rect x="3.5" y="2.5" width="3" height="11" rx="1"/><rect x="9.5" y="2.5" width="3" height="11" rx="1"/></svg></button>
          <video muted loop playsinline preload="none" poster="<?php echo esc_url(get_template_directory_uri()); ?>/assets/motion/motion-reel.jpg" aria-label="Motion graphics reel — reference clip by another creator"><source src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/motion/motion-reel.mp4" type="video/mp4"></video>
          <div class="clip-cap"><b>Motion graphics reel</b><span>UI · Promo · Titles</span></div>
        </div>
        <div class="clip-info">
          <p>Dark, techy motion design for launches, ads and brand reels.</p>
          <small>Reference reel · original creator via Pinterest</small>
          <a class="case-cta u-link" href="#contact" data-brief="motion">Brief a similar edit <svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M5 11l6-6m0 0H6m5 0v5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
        </div>
      </article>
    </div>

  </div>
</section>

<!-- ===================== CONTACT / BRIEF ===================== -->
<section class="section" id="contact" aria-labelledby="contactTitle">
  <div class="wrap">
    <header class="section-head">
      <p class="eyebrow" data-reveal><span class="idx">05</span><span class="rule"></span>Start a project</p>
      <h2 class="section-title" id="contactTitle" data-reveal>Tell us what you're <em class="h-em">building.</em></h2>
      <p class="section-lead" data-reveal style="--d:100ms">Four quick steps. You'll see an indicative scope as you go, and we'll reply with clear next steps.</p>
    </header>

    <div class="brief" id="brief" data-reveal>
      <div class="brief-main">
        <ol class="brief-steps" id="briefSteps" aria-label="Brief progress">
          <li class="is-current" aria-current="step"><span class="n">1</span><span class="t">Project</span></li>
          <li><span class="n">2</span><span class="t">Budget</span></li>
          <li><span class="n">3</span><span class="t">Timeline</span></li>
          <li><span class="n">4</span><span class="t">Details</span></li>
        </ol>
        <div class="brief-bar" aria-hidden="true"><span id="briefBar"></span></div>

        <form class="brief-form" id="briefForm" action="mailto:team.kuroagency@hotmail.com" method="post" enctype="text/plain" novalidate>
          <p class="sr-only" id="briefLive" aria-live="polite"></p>

          <fieldset class="brief-step is-active" data-step="1" aria-describedby="hint1">
            <legend class="brief-q" tabindex="-1">What are we building?</legend>
            <p class="brief-hint" id="hint1">Pick everything that applies — we'll refine it together.</p>
            <div class="opt-grid three">
              <label class="opt"><input type="checkbox" name="type" value="website"><span class="opt-card"><span class="opt-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3z"/></svg></span><span class="opt-title">Business or Gym Website</span><span class="opt-desc">High-converting custom site &amp; domain launch</span><span class="opt-check" aria-hidden="true"><svg viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></label>
              <label class="opt"><input type="checkbox" name="type" value="venue"><span class="opt-card"><span class="opt-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="7" width="19" height="11" rx="5.5"/><path d="M7.5 10.5v4M5.5 12.5h4M15.5 11.5h.01M18 13.5h.01"/></svg></span><span class="opt-title">Gaming Cafe / Venue Platform</span><span class="opt-desc">Catalog, pricing tiers &amp; slot booking</span><span class="opt-check" aria-hidden="true"><svg viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></label>
              <label class="opt"><input type="checkbox" name="type" value="automation"><span class="opt-card"><span class="opt-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/><path d="M12.5 8.5l-2.5 3.5h4l-2.5 3.5"/></svg></span><span class="opt-title">AI WhatsApp &amp; Lead Automation</span><span class="opt-desc">24/7 instant replies, CRM &amp; booking bots</span><span class="opt-check" aria-hidden="true"><svg viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></label>
              <label class="opt"><input type="checkbox" name="type" value="webapp"><span class="opt-card"><span class="opt-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="14" rx="2.5"/><path d="M8 21h8M7 9l2 2-2 2M12 13h4"/></svg></span><span class="opt-title">Web App / Custom Dashboard</span><span class="opt-desc">Next.js / Vite full-stack applications</span><span class="opt-check" aria-hidden="true"><svg viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></label>
              <label class="opt"><input type="checkbox" name="type" value="motion"><span class="opt-card"><span class="opt-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="14" height="14" rx="2.5"/><path d="M17 10l4-2.5v9L17 14"/></svg></span><span class="opt-title">Motion &amp; Launch Edits</span><span class="opt-desc">Promo reels, UI motion &amp; brand visuals</span><span class="opt-check" aria-hidden="true"><svg viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></label>
            </div>
            <p class="field-error" id="err1" role="alert" hidden>Pick at least one option to continue.</p>
          </fieldset>

          <fieldset class="brief-step" data-step="2" aria-describedby="hint2">
            <legend class="brief-q" tabindex="-1">What's your budget?</legend>
            <p class="brief-hint" id="hint2">A rough range is fine — it helps us shape the right team and phasing.</p>
            <div class="opt-grid">
              <label class="opt"><input type="radio" name="budget" value="0"><span class="opt-card plain"><span class="opt-title">Under $10k</span><span class="opt-desc">A focused sprint or single deliverable</span><span class="opt-check" aria-hidden="true"><svg viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></label>
              <label class="opt"><input type="radio" name="budget" value="1"><span class="opt-card plain"><span class="opt-title">$10k – $25k</span><span class="opt-desc">A website, brand identity or MVP</span><span class="opt-check" aria-hidden="true"><svg viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></label>
              <label class="opt"><input type="radio" name="budget" value="2"><span class="opt-card plain"><span class="opt-title">$25k – $50k</span><span class="opt-desc">A multi-part product or platform</span><span class="opt-check" aria-hidden="true"><svg viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></label>
              <label class="opt"><input type="radio" name="budget" value="3"><span class="opt-card plain"><span class="opt-title">$50k+</span><span class="opt-desc">A flagship build or ongoing partnership</span><span class="opt-check" aria-hidden="true"><svg viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></label>
            </div>
            <p class="field-error" id="err2" role="alert" hidden>Choose a range to continue — it doesn't need to be exact.</p>
          </fieldset>

          <fieldset class="brief-step" data-step="3" aria-describedby="hint3">
            <legend class="brief-q" tabindex="-1">When do you need it?</legend>
            <p class="brief-hint" id="hint3">We'll plan backwards from your date.</p>
            <div class="opt-grid">
              <label class="opt"><input type="radio" name="timeline" value="asap"><span class="opt-card plain"><span class="opt-title">As soon as possible</span><span class="opt-desc">Under 4 weeks</span><span class="opt-check" aria-hidden="true"><svg viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></label>
              <label class="opt"><input type="radio" name="timeline" value="short"><span class="opt-card plain"><span class="opt-title">1 – 3 months</span><span class="opt-desc">The most common timeline</span><span class="opt-check" aria-hidden="true"><svg viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></label>
              <label class="opt"><input type="radio" name="timeline" value="long"><span class="opt-card plain"><span class="opt-title">3 – 6 months</span><span class="opt-desc">Room to explore and phase</span><span class="opt-check" aria-hidden="true"><svg viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></label>
              <label class="opt"><input type="radio" name="timeline" value="flex"><span class="opt-card plain"><span class="opt-title">Flexible</span><span class="opt-desc">No fixed deadline yet</span><span class="opt-check" aria-hidden="true"><svg viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></label>
            </div>
            <p class="field-error" id="err3" role="alert" hidden>Choose a timeline to continue.</p>
          </fieldset>

          <fieldset class="brief-step" data-step="4" aria-describedby="hint4">
            <legend class="brief-q" tabindex="-1">Where should we send the plan?</legend>
            <p class="brief-hint" id="hint4">We'll reply with next steps and a time to talk.</p>
            <div class="fields">
              <div class="field"><label for="fName">Your name</label><input id="fName" name="name" type="text" autocomplete="name" placeholder="Alex Morgan" aria-describedby="errName"><p class="field-error" id="errName" hidden>Enter your name so we know who to reply to.</p></div>
              <div class="field"><label for="fEmail">Work email</label><input id="fEmail" name="email" type="email" autocomplete="email" inputmode="email" placeholder="alex@company.com" aria-describedby="errEmail"><p class="field-error" id="errEmail" hidden>Enter a valid email, like name@company.com.</p></div>
              <div class="field full"><label for="fCompany">Company <span class="opt-l">(optional)</span></label><input id="fCompany" name="company" type="text" autocomplete="organization" placeholder="Company or project name"></div>
              <div class="field full"><label for="fMsg">Anything else? <span class="opt-l">(optional)</span></label><textarea id="fMsg" name="message" rows="4" placeholder="Goals, links, current site, the problem you're solving…"></textarea></div>
            </div>
          </fieldset>

          <div class="brief-nav">
            <button class="btn btn-ghost" type="button" id="briefBack" hidden>
              <svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M13 8H3m0 0l4.5-4.5M3 8l4.5 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>Back</button>
            <span class="brief-count" id="briefCount">Step 1 of 4</span>
            <button class="btn btn-primary" type="submit" id="briefNext"><span id="briefNextLabel">Continue</span>
              <svg class="arr" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3 8h10m0 0L8.5 3.5M13 8l-4.5 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
          </div>
        </form>

        <div class="brief-done" id="briefDone" tabindex="-1" hidden>
          <span class="done-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none"><path d="M5 12.5l4.5 4.5L19 7.5" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
          <h3>Your brief is ready.</h3>
          <p>We've opened it in your email app, addressed to <a href="mailto:team.kuroagency@hotmail.com">team.kuroagency@hotmail.com</a> — just press send. Nothing opened? Send it on WhatsApp instead, or copy it and email us.</p>
          <div class="done-actions">
            <a class="btn btn-primary" id="briefWa" href="https://wa.me/918700268026" target="_blank" rel="noopener noreferrer">Send on WhatsApp</a>
            <button class="btn btn-ghost" type="button" id="briefCopy">Copy brief</button>
            <button class="btn btn-ghost" type="button" id="briefReset">Start a new brief</button>
          </div>
        </div>
      </div>

      <div class="brief-summary" role="region" aria-labelledby="sumTitle">
        <p class="eyebrow" id="sumTitle"><span class="pulse" aria-hidden="true"></span>Your brief</p>
        <dl class="sum-list">
          <div><dt>Project</dt><dd id="sumType" class="is-empty">Not chosen yet</dd></div>
          <div><dt>Budget</dt><dd id="sumBudget" class="is-empty">Not chosen yet</dd></div>
          <div><dt>Timeline</dt><dd id="sumTime" class="is-empty">Not chosen yet</dd></div>
        </dl>
        <div class="scope" aria-live="polite">
          <div class="scope-head"><span>Indicative scope</span><b id="scopeLabel">—</b></div>
          <div class="scope-meter" id="scopeMeter" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
          <ul class="scope-facts">
            <li><span>Typical duration</span><b id="scopeWeeks">—</b></li>
            <li><span>Usually starts from</span><b id="scopeFrom">—</b></li>
            <li><span>Who's involved</span><b id="scopeTeam">—</b></li>
          </ul>
          <p class="scope-note" id="scopeNote" hidden></p>
        </div>
        <p class="sum-foot">Indicative only. You'll get a fixed quote after a short discovery call.</p>
      </div>
    </div>
  </div>
</section>

<!-- ===================== FAQ ===================== -->
<section class="section" id="faq" aria-labelledby="faqTitle">
  <div class="wrap faq-grid">
    <div class="faq-aside">
      <p class="eyebrow" data-reveal><span class="idx">06</span><span class="rule"></span>FAQ</p>
      <h2 class="section-title" id="faqTitle" data-reveal>Questions, <em class="h-em">answered.</em></h2>
      <p data-reveal style="--d:100ms">Can't find what you're looking for? WhatsApp us on <a class="u-link" href="https://wa.me/918700268026" target="_blank" rel="noopener noreferrer" style="color:var(--text)">+91 870 026 8026</a> or email <a class="u-link" href="mailto:team.kuroagency@hotmail.com" style="color:var(--text)">team.kuroagency@hotmail.com</a> and a founder will reply.</p>
    </div>
    <div class="faq-list" data-reveal style="--d:120ms">
      <div class="faq-item">
        <h3><button class="faq-btn" type="button" aria-expanded="false" aria-controls="faq1" id="faqb1">How much does a project cost?<span class="pm" aria-hidden="true"></span></button></h3>
        <div class="faq-panel" id="faq1" role="region" aria-labelledby="faqb1"><div class="faq-inner"><p>Most engagements land between $10k and $80k, depending on scope. The brief builder above gives you an indicative range in seconds — after a short discovery call we'll send a fixed quote, so there are no surprises.</p></div></div>
      </div>
      <div class="faq-item">
        <h3><button class="faq-btn" type="button" aria-expanded="false" aria-controls="faq2" id="faqb2">How long does a typical project take?<span class="pm" aria-hidden="true"></span></button></h3>
        <div class="faq-panel" id="faq2" role="region" aria-labelledby="faqb2"><div class="faq-inner"><p>Brand identities usually take 3–5 weeks, marketing websites 4–8 weeks and web apps 8–16 weeks. Bigger builds ship in phases, so you see real progress — and real value — early.</p></div></div>
      </div>
      <div class="faq-item">
        <h3><button class="faq-btn" type="button" aria-expanded="false" aria-controls="faq3" id="faqb3">Who will we actually work with?<span class="pm" aria-hidden="true"></span></button></h3>
        <div class="faq-panel" id="faq3" role="region" aria-labelledby="faqb3"><div class="faq-inner"><p>The founders. We're a three-person studio by choice — the people on your first call are the people designing, building and launching your project.</p></div></div>
      </div>
      <div class="faq-item">
        <h3><button class="faq-btn" type="button" aria-expanded="false" aria-controls="faq4" id="faqb4">What's your tech stack?<span class="pm" aria-hidden="true"></span></button></h3>
        <div class="faq-panel" id="faq4" role="region" aria-labelledby="faqb4"><div class="faq-inner"><p>We default to TypeScript, React and Next.js, with headless CMSs like Sanity or Contentful, Shopify for commerce and Vercel for hosting. Already have a stack? We'll work with it.</p></div></div>
      </div>
      <div class="faq-item">
        <h3><button class="faq-btn" type="button" aria-expanded="false" aria-controls="faq5" id="faqb5">Do you work with early-stage startups?<span class="pm" aria-hidden="true"></span></button></h3>
        <div class="faq-panel" id="faq5" role="region" aria-labelledby="faqb5"><div class="faq-inner"><p>Yes. We regularly take founders from idea to a launch-ready brand and MVP, and we can phase the work to fit a pre-seed or seed budget.</p></div></div>
      </div>
      <div class="faq-item">
        <h3><button class="faq-btn" type="button" aria-expanded="false" aria-controls="faq6" id="faqb6">What happens after launch?<span class="pm" aria-hidden="true"></span></button></h3>
        <div class="faq-panel" id="faq6" role="region" aria-labelledby="faqb6"><div class="faq-inner"><p>You choose. We offer monthly care plans covering updates, monitoring and conversion experiments — or we hand everything over with documentation so your team can run with it.</p></div></div>
      </div>
    </div>
  </div>
</section>

</main>

<!-- ===================== FOOTER ===================== -->
<footer class="site-footer" aria-labelledby="footerTitle">
  <div class="footer-glow" aria-hidden="true"></div>
  <div class="wrap">
    <div class="footer-cta">
      <p class="eyebrow" data-reveal><span class="pulse" aria-hidden="true"></span>Taking new projects</p>
      <h2 id="footerTitle" data-reveal>Let's build something <em class="h-em">exceptional</em> together.</h2>
      <div class="footer-cta-row" data-reveal style="--d:120ms">
        <a class="btn btn-primary btn-lg" href="#contact">Start your brief
          <svg class="arr" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3 8h10m0 0L8.5 3.5M13 8l-4.5 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </a>
        <span class="mail-link"><a class="u-link" href="mailto:team.kuroagency@hotmail.com">team.kuroagency@hotmail.com</a>
          <button class="copy-btn" type="button" id="copyEmail" aria-label="Copy email address"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2.5"/><path d="M5 15V6.5A2.5 2.5 0 0 1 7.5 4H15"/></svg></button>
          <span class="copy-tip" id="copyTip" aria-live="polite"></span>
        </span>
        <a class="btn btn-ghost btn-lg" href="https://wa.me/918700268026" target="_blank" rel="noopener noreferrer">WhatsApp +91 870 026 8026</a>
      </div>
    </div>

    <div class="footer-cols">
      <div class="f-col f-brand">
        <a class="brand" href="#top" aria-label="KURO — back to top"><span class="brand-word" aria-hidden="true">KURO<i></i></span><span class="brand-tag" aria-hidden="true"><span>黒 / Studio</span><span>Est. 2026</span></span></a>
        <p>An independent design and engineering studio for brands that want to be remembered.</p>
      </div>
      <div class="f-col">
        <h3>Studio</h3>
        <ul>
          <li class="office"><b>Mumbai</b><span>India</span></li>
          <li class="office"><b>Remote</b><span>Working with clients worldwide</span></li>
          <li><span class="f-time"><span class="pulse" aria-hidden="true"></span><span id="localTime">—</span></span></li>
        </ul>
      </div>
      <div class="f-col">
        <h3>Contact</h3>
        <ul>
          <li><span class="office"><span>New projects</span><a href="mailto:team.kuroagency@hotmail.com">team.kuroagency@hotmail.com</a></span></li>
          <li><span class="office"><span>WhatsApp / Call</span><a href="https://wa.me/918700268026" target="_blank" rel="noopener noreferrer">+91 870 026 8026</a></span></li>
        </ul>
      </div>
      <div class="f-col social">
        <h3>Social</h3>
        <ul>
          <li><a href="https://x.com/" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M18.24 2.25h3.31l-7.23 8.26 8.5 11.24h-6.65l-5.21-6.82-5.97 6.82H1.68l7.73-8.84L1.25 2.25h6.83l4.71 6.23zm-1.16 17.52h1.83L7.08 4.13H5.12z"/></svg>Twitter / X<svg class="ext" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M5 11l6-6m0 0H6m5 0v5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></li>
          <li><a href="https://www.linkedin.com/" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20.45 20.45h-3.55v-5.57c0-1.33-.03-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.35V9h3.41v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.06 2.06 0 1 1 0-4.13 2.06 2.06 0 0 1 0 4.13zm1.78 13.02H3.56V9h3.56zM22.22 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.73V1.73C24 .77 23.2 0 22.22 0z"/></svg>LinkedIn<svg class="ext" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M5 11l6-6m0 0H6m5 0v5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></li>
          <li><a href="https://github.com/" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 .3a12 12 0 0 0-3.8 23.38c.6.12.83-.26.83-.57l-.02-2.04c-3.34.73-4.04-1.6-4.04-1.6-.55-1.4-1.34-1.77-1.34-1.77-1.08-.74.09-.73.09-.73 1.2.09 1.84 1.24 1.84 1.24 1.07 1.83 2.8 1.3 3.49 1 .1-.78.42-1.31.76-1.61-2.67-.3-5.47-1.33-5.47-5.93 0-1.31.47-2.38 1.24-3.22-.14-.3-.54-1.52.1-3.18 0 0 1-.32 3.3 1.23a11.5 11.5 0 0 1 6 0c2.28-1.55 3.29-1.23 3.29-1.23.64 1.66.24 2.88.12 3.18a4.65 4.65 0 0 1 1.23 3.22c0 4.61-2.8 5.63-5.48 5.92.42.36.81 1.1.81 2.22l-.01 3.29c0 .31.2.69.82.57A12 12 0 0 0 12 .3"/></svg>GitHub<svg class="ext" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M5 11l6-6m0 0H6m5 0v5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></li>
          <li><a href="https://dribbble.com/" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="12" cy="12" r="9.5"/><path d="M5.6 5.6c3.6 3.4 8.4 4.7 15.6 4.1M8 20.7c1.6-5 5.4-8 13.4-7.4M8.4 3.1c3.2 3.7 5.9 9.2 7.3 17.9"/></svg>Dribbble<svg class="ext" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M5 11l6-6m0 0H6m5 0v5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></li>
        </ul>
      </div>
    </div>

    <div class="footer-bottom">
      <span>© <span id="year">2026</span> KURO Studio. All rights reserved.</span>
      <div class="links">
        <button type="button" id="shareBtn" aria-haspopup="dialog" aria-controls="shareSheet">Share this site</button>
        <a href="#top">Back to top ↑</a>
      </div>
    </div>
  </div>
  <div class="footer-word" aria-hidden="true">KURO</div>
</footer>

<!-- ===================== SHARE SHEET ===================== -->
<div class="ss-backdrop" id="shareSheet" hidden>
  <div class="ss-sheet" role="dialog" aria-modal="true" aria-labelledby="ssTitle">
    <div class="ss-head">
      <div><h2 id="ssTitle">Share KURO</h2><p id="ssUrlText"></p></div>
      <button class="ss-close" id="ssClose" type="button" aria-label="Close share sheet"><svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3.5 3.5l9 9m0-9l-9 9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button>
    </div>
    <div class="ss-qr"><span class="ph" id="ssQrPh"></span><img id="ssQr" alt="QR code linking to the KURO website" width="104" height="104" hidden><div><b>Scan to open</b>Point a phone camera at the code — no app needed.</div></div>
    <div class="ss-link"><input id="ssUrlInput" type="text" readonly aria-label="Site link"><button class="btn btn-primary btn-sm" id="ssCopy" type="button">Copy</button></div>
    <div class="ss-grid" id="ssGrid"></div>
    <button class="btn btn-ghost ss-dl" type="button" id="ssDownload">Download QR code</button>
  </div>
</div>

<script>
(() => {
  'use strict';
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const finePointer = matchMedia('(hover: hover) and (pointer: fine)').matches;

  /* ---------- Hero entrance ---------- */
  const ready = () => requestAnimationFrame(() => document.documentElement.classList.add('is-ready'));
  if (document.fonts && document.fonts.ready) {
    Promise.race([document.fonts.ready, new Promise(r => setTimeout(r, 700))]).then(ready);
  } else ready();

  /* ---------- Smart header ---------- */
  const header = $('#siteHeader');
  let lastY = scrollY, ticking = false, menuOpen = false;
  const onScroll = () => {
    const y = Math.max(0, scrollY), dy = y - lastY;
    header.classList.toggle('is-condensed', y > 24);
    if (menuOpen || y < 160 || dy < -4) header.classList.remove('is-hidden');
    else if (dy > 4 && !header.contains(document.activeElement)) header.classList.add('is-hidden');
    lastY = y; ticking = false;
  };
  addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true });
  header.addEventListener('focusin', () => header.classList.remove('is-hidden'));
  onScroll();

  /* ---------- Scrollspy ---------- */
  const navMap = new Map($$('.nav-links a').map(a => [a.getAttribute('href').slice(1), a]));
  const spy = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      navMap.forEach(a => a.classList.remove('is-active'));
      const a = navMap.get(e.target.id === 'faq' ? 'contact' : e.target.id);
      if (a) a.classList.add('is-active');
    });
  }, { rootMargin: '-45% 0px -50% 0px' });
  ['top', 'services', 'work', 'automation', 'motion', 'contact', 'faq'].forEach(id => { const el = document.getElementById(id); if (el) spy.observe(el); });

  /* ---------- Mobile menu ---------- */
  const toggle = $('#menuToggle'), menu = $('#mobileMenu'), main = $('#main'), footer = $('.site-footer');
  const setMenu = open => {
    menuOpen = open;
    menu.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    document.documentElement.style.overflow = open ? 'hidden' : '';
    main.inert = open; footer.inert = open;
    if (open) { header.classList.remove('is-hidden'); setTimeout(() => $('.mm-links a', menu).focus({ preventScroll: true }), 350); }
  };
  menu.inert = true;
  toggle.addEventListener('click', () => { const o = !menuOpen; menu.inert = !o; setMenu(o); });
  menu.addEventListener('click', e => { if (e.target.closest('a')) { setMenu(false); menu.inert = true; } });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && menuOpen) { setMenu(false); menu.inert = true; toggle.focus(); }
    if (e.key === 'Tab' && menuOpen) {
      const f = [toggle, ...$$('a, button', menu)];
      const i = f.indexOf(document.activeElement);
      if (e.shiftKey && i <= 0) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); }
    }
  });
  matchMedia('(min-width: 920px)').addEventListener('change', e => { if (e.matches && menuOpen) { setMenu(false); menu.inert = true; } });

  /* ---------- Hero pointer lens + glow (transform-only) ---------- */
  const hero = $('.hero'), lens = $('#heroLens'), lensGrid = $('#heroLensGrid'), glow = $('#heroGlow');
  if (finePointer && !reduceMotion && hero) {
    const R = 220;
    let rect = null, tx = 0, ty = 0, lx = 0, ly = 0, gx = 0, gy = 0, raf = 0;
    const measure = () => { rect = hero.getBoundingClientRect(); lensGrid.style.width = rect.width + 'px'; lensGrid.style.height = rect.height + 'px'; };
    const loop = () => {
      lx += (tx - lx) * .2; ly += (ty - ly) * .2; gx += (tx - gx) * .07; gy += (ty - gy) * .07;
      lens.style.transform = `translate3d(${lx}px,${ly}px,0)`;
      lensGrid.style.transform = `translate3d(${R - lx}px,${R - ly}px,0)`;
      glow.style.transform = `translate3d(${gx}px,${gy}px,0)`;
      raf = (Math.abs(tx - lx) + Math.abs(ty - ly) + Math.abs(tx - gx) + Math.abs(ty - gy) > .4) ? requestAnimationFrame(loop) : 0;
    };
    hero.addEventListener('pointerenter', e => {
      measure(); tx = lx = gx = e.clientX - rect.left; ty = ly = gy = e.clientY - rect.top;
      hero.classList.add('is-pointer'); if (!raf) raf = requestAnimationFrame(loop);
    });
    hero.addEventListener('pointerleave', () => hero.classList.remove('is-pointer'));
    hero.addEventListener('pointermove', e => {
      if (!rect) measure();
      tx = e.clientX - rect.left; ty = e.clientY - rect.top;
      if (!raf) raf = requestAnimationFrame(loop);
    }, { passive: true });
    addEventListener('scroll', () => { rect = null; }, { passive: true });
    addEventListener('resize', () => { rect = null; });
  }

  /* ---------- Bento border tracking ---------- */
  if (finePointer && !reduceMotion) {
    $$('[data-spotlight]').forEach(card => {
      const dots = $$('.card-ring i, .card-spot i', card);
      let raf = 0, x = 0, y = 0;
      card.addEventListener('pointermove', e => {
        const r = card.getBoundingClientRect(); x = e.clientX - r.left; y = e.clientY - r.top;
        if (!raf) raf = requestAnimationFrame(() => { raf = 0; const t = `translate3d(${x}px,${y}px,0)`; dots.forEach(d => d.style.transform = t); });
      }, { passive: true });
    });
  }

  /* ---------- Scroll reveal ---------- */
  $$('[data-stagger]').forEach(g => $$(':scope > [data-reveal]', g).forEach((el, i) => { if (!el.style.getPropertyValue('--d')) el.style.setProperty('--d', (i % 4) * 90 + 'ms'); }));
  const io = new IntersectionObserver(entries => entries.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add('is-in'); io.unobserve(e.target); }
  }), { threshold: .12, rootMargin: '0px 0px -6% 0px' });
  $$('[data-reveal]').forEach(el => io.observe(el));

  /* ---------- Motion reel: play only while visible ---------- */
  const clips = $$('.clip');
  const setPaused = (clip, paused) => {
    clip.classList.toggle('is-paused', paused);
    const b = $('.clip-toggle', clip), t = $('.clip-cap b', clip).textContent.toLowerCase();
    b.setAttribute('aria-label', (paused ? 'Play ' : 'Pause ') + t + ' video');
  };
  clips.forEach(clip => {
    const v = $('video', clip);
    clip._userPaused = reduceMotion;
    setPaused(clip, true);
    $('.clip-toggle', clip).addEventListener('click', () => {
      if (v.paused) { clip._userPaused = false; v.play().catch(() => {}); }
      else { clip._userPaused = true; v.pause(); }
    });
    v.addEventListener('play', () => setPaused(clip, false));
    v.addEventListener('pause', () => setPaused(clip, true));
  });
  const vio = new IntersectionObserver(entries => entries.forEach(e => {
    const clip = e.target, v = $('video', clip);
    if (e.isIntersecting && !clip._userPaused) { if (v.preload === 'none') v.preload = 'auto'; v.play().catch(() => setPaused(clip, true)); }
    else if (!e.isIntersecting && !v.paused) v.pause();
  }), { threshold: .4 });
  clips.forEach(c => vio.observe(c));

  /* ---------- FAQ accordion ---------- */
  $$('.faq-item').forEach(item => {
    const btn = $('.faq-btn', item);
    btn.addEventListener('click', () => {
      const open = !item.classList.contains('is-open');
      item.classList.toggle('is-open', open);
      btn.setAttribute('aria-expanded', String(open));
    });
  });

  /* ---------- Brief builder ---------- */
  const TYPES = {
    website:    { label: 'Business or Gym Website',       w: 2, weeks: [2, 4],  team: ['Design', 'Engineering'] },
    venue:      { label: 'Gaming Cafe / Venue Platform',  w: 3, weeks: [3, 6],  team: ['Design', 'Engineering'] },
    automation: { label: 'AI WhatsApp & Lead Automation', w: 2, weeks: [1, 3],  team: ['Automation'] },
    webapp:     { label: 'Web App / Custom Dashboard',    w: 4, weeks: [6, 12], team: ['Design', 'Engineering'] },
    motion:     { label: 'Motion & Launch Edits',         w: 1, weeks: [1, 2],  team: ['Motion'] }
  };
  const BUDGETS = [
    { label: 'Under $10k', max: 10000 },
    { label: '$10k – $25k', max: 25000 },
    { label: '$25k – $50k', max: 50000 },
    { label: '$50k+', max: Infinity }
  ];
  const TIMES = {
    asap:  { label: 'As soon as possible', weeks: 4 },
    short: { label: '1 – 3 months', weeks: 13 },
    long:  { label: '3 – 6 months', weeks: 26 },
    flex:  { label: 'Flexible', weeks: Infinity }
  };
  const LEVELS = [
    { max: 1, label: 'Quick edit', from: 500 },
    { max: 2, label: 'Focused', from: 8000 },
    { max: 4, label: 'Considered', from: 15000 },
    { max: 7, label: 'Comprehensive', from: 30000 },
    { max: Infinity, label: 'Flagship', from: 50000 }
  ];
  const money = n => n < 1000 ? '$' + n : '$' + (n / 1000) + 'k';

  const form = $('#briefForm'), steps = $$('.brief-step', form), stepItems = $$('#briefSteps li');
  const backBtn = $('#briefBack'), nextLabel = $('#briefNextLabel'), count = $('#briefCount'), bar = $('#briefBar'), live = $('#briefLive');
  const done = $('#briefDone');
  let step = 1, lastBrief = '';

  const state = () => {
    const types = $$('input[name="type"]:checked', form).map(i => i.value);
    const b = $('input[name="budget"]:checked', form);
    const t = $('input[name="timeline"]:checked', form);
    return { types, budget: b ? +b.value : null, time: t ? t.value : null };
  };

  const estimate = s => {
    if (!s.types.length) return null;
    const list = s.types.map(k => TYPES[k]).sort((a, b) => b.weeks[1] - a.weeks[1]);
    const score = list.reduce((n, t) => n + t.w, 0);
    const [p, ...rest] = list;
    const lo = Math.round(p.weeks[0] + rest.reduce((n, t) => n + t.weeks[0], 0) * .4);
    const hi = Math.round(p.weeks[1] + rest.reduce((n, t) => n + t.weeks[1], 0) * .4);
    const levelIdx = LEVELS.findIndex(l => score <= l.max);
    const team = [...new Set(list.flatMap(t => t.team))];
    return { lo, hi, level: LEVELS[levelIdx], levelIdx, team };
  };

  const setText = (el, txt, empty) => {
    if (el.textContent === txt) return;
    el.textContent = txt;
    el.classList.toggle('is-empty', !!empty);
    el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash');
  };

  const updateSummary = () => {
    const s = state(), est = estimate(s);
    setText($('#sumType'), s.types.length ? s.types.map(k => TYPES[k].label).join(', ') : 'Not chosen yet', !s.types.length);
    setText($('#sumBudget'), s.budget !== null ? BUDGETS[s.budget].label : 'Not chosen yet', s.budget === null);
    setText($('#sumTime'), s.time ? TIMES[s.time].label : 'Not chosen yet', !s.time);
    $$('#scopeMeter i').forEach((i, n) => i.classList.toggle('on', !!est && n < Math.max(1, est.levelIdx)));
    setText($('#scopeLabel'), est ? est.level.label : '—');
    setText($('#scopeWeeks'), est ? `${est.lo}–${est.hi} weeks` : '—');
    setText($('#scopeFrom'), est ? money(est.level.from) : '—');
    setText($('#scopeTeam'), est ? est.team.join(' + ') : '—');
    const notes = [];
    if (est && s.budget !== null && BUDGETS[s.budget].max < est.level.from)
      notes.push(`This scope usually starts around ${money(est.level.from)} — we can phase it to fit your budget.`);
    if (est && s.time && TIMES[s.time].weeks < est.lo)
      notes.push(`That's a tight timeline for this scope — we'd suggest launching a focused first phase.`);
    const note = $('#scopeNote');
    note.hidden = !notes.length;
    note.textContent = notes.join(' ');
  };

  const showError = (id, show) => { const el = document.getElementById(id); if (el) el.hidden = !show; };

  const validate = n => {
    const s = state();
    if (n === 1) { showError('err1', !s.types.length); return !!s.types.length; }
    if (n === 2) { showError('err2', s.budget === null); return s.budget !== null; }
    if (n === 3) { showError('err3', !s.time); return !!s.time; }
    if (n === 4) {
      const name = $('#fName'), email = $('#fEmail');
      const okName = name.value.trim().length > 1;
      const okEmail = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.value.trim());
      name.setAttribute('aria-invalid', String(!okName)); showError('errName', !okName);
      email.setAttribute('aria-invalid', String(!okEmail)); showError('errEmail', !okEmail);
      if (!okName) name.focus(); else if (!okEmail) email.focus();
      return okName && okEmail;
    }
    return true;
  };

  const go = (n, dir) => {
    step = n;
    form.dataset.dir = dir || 'next';
    steps.forEach(f => f.classList.toggle('is-active', +f.dataset.step === n));
    stepItems.forEach((li, i) => {
      li.classList.toggle('is-current', i + 1 === n);
      li.classList.toggle('is-done', i + 1 < n);
      if (i + 1 === n) li.setAttribute('aria-current', 'step'); else li.removeAttribute('aria-current');
    });
    bar.style.transform = `scaleX(${n / 4})`;
    backBtn.hidden = n === 1;
    nextLabel.textContent = n === 4 ? 'Send brief' : 'Continue';
    count.textContent = `Step ${n} of 4`;
    live.textContent = `Step ${n} of 4: ${$('.brief-q', steps[n - 1]).textContent}`;
  };

  const compose = () => {
    const s = state(), est = estimate(s);
    const v = id => document.getElementById(id).value.trim();
    return [
      'New project brief — via kuro website', '',
      `Project:   ${s.types.map(k => TYPES[k].label).join(', ')}`,
      `Budget:    ${BUDGETS[s.budget].label}`,
      `Timeline:  ${TIMES[s.time].label}`,
      est ? `Scope:     ${est.level.label} · ${est.lo}–${est.hi} weeks` : '', '',
      `Name:      ${v('fName')}`,
      `Email:     ${v('fEmail')}`,
      `Company:   ${v('fCompany') || '—'}`, '',
      'Notes:', v('fMsg') || '—'
    ].join('\n');
  };

  form.addEventListener('change', e => {
    updateSummary();
    if (e.target.name === 'type') showError('err1', false);
    if (e.target.name === 'budget') showError('err2', false);
    if (e.target.name === 'timeline') showError('err3', false);
  });
  form.addEventListener('input', e => {
    if (e.target.id === 'fName' && e.target.getAttribute('aria-invalid') === 'true' && e.target.value.trim().length > 1) { e.target.setAttribute('aria-invalid', 'false'); showError('errName', false); }
    if (e.target.id === 'fEmail' && e.target.getAttribute('aria-invalid') === 'true' && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e.target.value.trim())) { e.target.setAttribute('aria-invalid', 'false'); showError('errEmail', false); }
  });
  form.addEventListener('submit', e => {
    e.preventDefault();
    if (!validate(step)) return;
    if (step < 4) { go(step + 1, 'next'); $('.brief-q', steps[step - 1]).focus({ preventScroll: true }); return; }
    lastBrief = compose();
    const s = state();
    const subject = `New project brief — ${$('#fCompany').value.trim() || $('#fName').value.trim()} (${s.types.map(k => TYPES[k].label).join(', ')})`;
    location.href = `mailto:team.kuroagency@hotmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(lastBrief)}`;
    $('#briefWa').href = 'https://wa.me/918700268026?text=' + encodeURIComponent(lastBrief);
    form.hidden = true; $('#briefSteps').hidden = true; $('.brief-bar').hidden = true;
    done.hidden = false; done.focus({ preventScroll: true });
  });
  backBtn.addEventListener('click', () => { if (step > 1) { go(step - 1, 'back'); $('.brief-q', steps[step - 1]).focus({ preventScroll: true }); } });

  const copyText = async txt => {
    try { await navigator.clipboard.writeText(txt); return true; }
    catch {
      const ta = document.createElement('textarea'); ta.value = txt; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select(); let ok = false; try { ok = document.execCommand('copy'); } catch {} ta.remove(); return ok;
    }
  };
  $('#briefCopy').addEventListener('click', async e => {
    const ok = await copyText(lastBrief); const b = e.currentTarget;
    b.textContent = ok ? 'Copied to clipboard' : 'Copy failed — select manually';
    setTimeout(() => b.textContent = 'Copy brief', 2200);
  });
  $('#briefReset').addEventListener('click', () => {
    form.reset(); updateSummary();
    ['err1', 'err2', 'err3', 'errName', 'errEmail'].forEach(id => showError(id, false));
    done.hidden = true; form.hidden = false; $('#briefSteps').hidden = false; $('.brief-bar').hidden = false;
    go(1, 'back'); $('.brief-q', steps[0]).focus({ preventScroll: true });
  });

  // "Start a similar project" pre-fills the brief
  $$('[data-brief]').forEach(a => a.addEventListener('click', () => {
    const want = a.dataset.brief.split(',');
    $$('input[name="type"]', form).forEach(i => { i.checked = want.includes(i.value); });
    if (!done.hidden) $('#briefReset').click();
    go(1, 'back'); updateSummary(); showError('err1', false);
  }));

  go(1); updateSummary();

  /* ---------- Footer: time, year, copy email ---------- */
  const timeEl = $('#localTime');
  const tick = () => {
    const f = new Intl.DateTimeFormat('en-GB', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Kolkata' });
    timeEl.textContent = `${f.format(new Date())} IST in Mumbai`;
  };
  tick(); setInterval(tick, 30000);
  $('#year').textContent = new Date().getFullYear();
  const tip = $('#copyTip');
  $('#copyEmail').addEventListener('click', async () => {
    const ok = await copyText('team.kuroagency@hotmail.com');
    tip.textContent = ok ? 'Copied' : 'Press ⌘/Ctrl + C';
    tip.classList.add('show'); clearTimeout(tip._t); tip._t = setTimeout(() => tip.classList.remove('show'), 1800);
  });

  /* ---------- Share sheet (QR loads lazily) ---------- */
  const LIVE_URL = 'https://kuro-agency-website.vercel.app/';
  const url = location.protocol.startsWith('http') ? location.origin + location.pathname : LIVE_URL;
  const sheet = $('#shareSheet'), shareBtn = $('#shareBtn'), ssClose = $('#ssClose'), qrImg = $('#ssQr'), qrPh = $('#ssQrPh');
  $('#ssUrlText').textContent = url; $('#ssUrlInput').value = url;
  const enc = encodeURIComponent, msg = 'KURO — design & engineering studio';
  const dests = [
    ['WhatsApp', 'https://wa.me/?text=' + enc(msg + ' ' + url), '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.2 14.2c-.2.6-1.2 1.2-1.7 1.2-.5.1-1 .1-1.7-.1-1.7-.6-3.5-1.7-4.9-3.5-.6-.8-1.1-1.7-1.1-2.4 0-.6.3-1.2.7-1.6.2-.2.4-.3.6-.3h.5c.2 0 .4 0 .6.5l.7 1.7c.1.2 0 .4-.1.6l-.4.5c-.1.2-.2.3-.1.5.4.8 1 1.5 1.8 2 .2.1.4.1.5 0l.6-.7c.2-.2.3-.2.5-.1l1.6.8c.2.1.4.2.4.4.1.2.1.7-.1 1z"/></svg>'],
    ['Telegram', 'https://t.me/share/url?url=' + enc(url) + '&text=' + enc(msg), '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.9 4.3 18.6 20c-.2 1-.9 1.3-1.8.8l-4.9-3.6-2.4 2.3c-.3.3-.5.5-1 .5l.4-5 9.1-8.2c.4-.4-.1-.6-.6-.2L6.2 13.1 1.2 11.6c-1.1-.3-1.1-1.1.2-1.6l19.1-7.4c.9-.3 1.6.2 1.4 1.7z"/></svg>'],
    ['X', 'https://twitter.com/intent/tweet?text=' + enc(msg) + '&url=' + enc(url), '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M18.24 2.25h3.31l-7.23 8.26 8.5 11.24h-6.65l-5.21-6.82-5.97 6.82H1.68l7.73-8.84L1.25 2.25h6.83l4.71 6.23zm-1.16 17.52h1.83L7.08 4.13H5.12z"/></svg>'],
    ['Email', 'mailto:?subject=' + enc(msg) + '&body=' + enc('Have a look: ' + url), '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="m4 7 8 6 8-6"/></svg>']
  ];
  $('#ssGrid').innerHTML = dests.map(([n, href, icon]) => `<a class="ss-dest" href="${href}" target="_blank" rel="noopener">${icon}<span>${n}</span></a>`).join('');
  let qrData = null, qrLoading = false;
  const makeQR = () => {
    try { const q = qrcode(0, 'M'); q.addData(url); q.make(); qrData = q.createDataURL(10, 2); qrImg.src = qrData; qrImg.hidden = false; qrPh.hidden = true; } catch (e) {}
  };
  const loadQR = () => {
    if (qrData || qrLoading) return; qrLoading = true;
    const sc = document.createElement('script');
    sc.src = 'https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js';
    sc.onload = makeQR; document.head.appendChild(sc);
  };
  const openSheet = () => {
    loadQR(); sheet.hidden = false; document.documentElement.style.overflow = 'hidden';
    requestAnimationFrame(() => requestAnimationFrame(() => sheet.classList.add('open'))); ssClose.focus();
  };
  const closeSheet = () => {
    sheet.classList.remove('open'); document.documentElement.style.overflow = '';
    setTimeout(() => { sheet.hidden = true; shareBtn.focus(); }, 300);
  };
  shareBtn.addEventListener('click', openSheet);
  ssClose.addEventListener('click', closeSheet);
  sheet.addEventListener('click', e => { if (e.target === sheet) closeSheet(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !sheet.hidden) closeSheet(); });
  $('#ssCopy').addEventListener('click', async e => { const ok = await copyText(url); e.currentTarget.textContent = ok ? 'Copied' : 'Copy'; setTimeout(() => $('#ssCopy').textContent = 'Copy', 1500); });
  $('#ssDownload').addEventListener('click', () => { if (!qrData) return; const a = document.createElement('a'); a.href = qrData; a.download = 'kuro-qr.png'; document.body.appendChild(a); a.click(); a.remove(); });
})();
</script>
<?php wp_footer(); ?>
</body>
</html>
